/*
========================================
FORA DO LÁPIS - SISTEMA DE AGENDAMENTO
JavaScript principal
========================================
*/

const DISCIPLINAS_PADRAO = ["Matemática", "Português", "Inglês", "Física"];

/* ---------- Storage helpers ---------- */

var DISP_PADRAO = {
    dias: [1, 2, 3, 4, 5],
    horarios: ["08:00", "10:00", "14:00", "16:00", "18:00"]
};

var DIAS_NOMES = { 0: "Dom", 1: "Seg", 2: "Ter", 3: "Qua", 4: "Qui", 5: "Sex", 6: "Sáb" };

function normalizarDisciplinasProf(p) {
    if (!p) return p;
    var list = [];
    if (Array.isArray(p.disciplinas) && p.disciplinas.length) {
        list = p.disciplinas.map(function (d) { return String(d).trim(); }).filter(Boolean);
    } else if (p.disciplina) {
        list = String(p.disciplina).split(",").map(function (d) { return d.trim(); }).filter(Boolean);
    }
    if (!list.length) list = ["Geral"];
    p.disciplinas = list;
    p.disciplina = list[0];
    return p;
}

function getDisciplinasDoProfessor(p) {
    normalizarDisciplinasProf(p);
    return (p && p.disciplinas) ? p.disciplinas.slice() : [];
}

function professorEnsina(p, disciplina) {
    if (!disciplina) return true;
    var list = getDisciplinasDoProfessor(p);
    return list.some(function (d) { return d.toLowerCase() === String(disciplina).toLowerCase(); });
}

function getProfessores() {
    const salvos = JSON.parse(localStorage.getItem("professores") || "[]");
    if (salvos.length === 0) {
        return [
            { id: 1, nome: "Gabriel Santos", email: "gabriel@email.com", disciplina: "Matemática", disciplinas: ["Matemática", "Física"], tipo: "professor", bio: "Especialista em álgebra e geometria.", bannerCor: 1, disponibilidade: { dias: [1,2,3,4,5], horarios: ["08:00","10:00","14:00","16:00","18:00"] } },
            { id: 2, nome: "Mariana Oliveira", email: "mariana@email.com", disciplina: "Português", disciplinas: ["Português", "Redação"], tipo: "professor", bio: "Gramática, literatura e redação.", bannerCor: 2, disponibilidade: { dias: [1,2,3,4,5], horarios: ["09:00","11:00","14:00","16:00"] } },
            { id: 3, nome: "Lucas Almeida", email: "lucas@email.com", disciplina: "Inglês", disciplinas: ["Inglês", "Espanhol"], tipo: "professor", bio: "Conversação e preparação para exames.", bannerCor: 3, disponibilidade: { dias: [1,3,5,6], horarios: ["10:00","14:00","16:00","18:00","19:00"] } }
        ].map(normalizarDisciplinasProf);
    }
    return salvos.map(normalizarDisciplinasProf);
}

function setProfessores(lista) {
    localStorage.setItem("professores", JSON.stringify(lista));
}

function getAlunos() {
    return JSON.parse(localStorage.getItem("alunos") || "[]");
}

function setAlunos(lista) {
    localStorage.setItem("alunos", JSON.stringify(lista));
}

function getAgendamentos() {
    return JSON.parse(localStorage.getItem("agendamentos") || "[]");
}

function setAgendamentos(lista) {
    localStorage.setItem("agendamentos", JSON.stringify(lista));
}

function getUsuarioLogado() {
    return JSON.parse(localStorage.getItem("usuarioLogado") || "null");
}

function setUsuarioLogado(usuario) {
    if (usuario) {
        localStorage.setItem("usuarioLogado", JSON.stringify(usuario));
    } else {
        localStorage.removeItem("usuarioLogado");
    }
}

/* ---------- Foto de perfil e anexos do professor ---------- */

function lerArquivoComoDataURL(file, maxBytes, callback) {
    if (!file) return;
    if (maxBytes && file.size > maxBytes) {
        mostrarToast("Arquivo muito grande. Máximo: " + Math.round(maxBytes / 1024) + " KB.");
        return;
    }
    var reader = new FileReader();
    reader.onload = function (e) {
        callback(e.target.result, file);
    };
    reader.onerror = function () {
        mostrarToast("Erro ao ler o arquivo.");
    };
    reader.readAsDataURL(file);
}

function aplicarFotoNoAvatar(avatarEl, usuario) {
    if (!avatarEl) return;
    if (usuario && usuario.foto) {
        avatarEl.classList.add("has-photo");
        var pos = (usuario.fotoPos && typeof usuario.fotoPos === "object") ? usuario.fotoPos : { scale: 1, x: 50, y: 50 };
        var style = "object-fit:cover;object-position:" + (pos.x || 50) + "% " + (pos.y || 50) + "%;transform:scale(" + (pos.scale || 1) + ");";
        avatarEl.innerHTML = '<img src="' + usuario.foto + '" alt="Foto de perfil" style="' + style + '">';
    } else {
        avatarEl.classList.remove("has-photo");
        avatarEl.innerHTML = "";
        avatarEl.textContent = ((usuario && usuario.nome) || "?").charAt(0).toUpperCase();
    }
}

var _fotoEditCallback = null;
var _fotoEditDataUrl = null;

function setupFotoPerfil(avatarEl, inputEl, onSave) {
    if (!avatarEl || !inputEl) return;
    avatarEl.style.cursor = "pointer";
    avatarEl.title = "Clique para alterar a foto";
    avatarEl.addEventListener("click", function () {
        inputEl.click();
    });
    inputEl.addEventListener("change", function () {
        var file = inputEl.files && inputEl.files[0];
        if (!file) return;
        if (!file.type || file.type.indexOf("image/") !== 0) {
            mostrarToast("Selecione uma imagem (JPG, PNG, etc.).");
            inputEl.value = "";
            return;
        }
        // Máx. ~400 KB para não estourar localStorage
        lerArquivoComoDataURL(file, 400 * 1024, function (dataUrl) {
            abrirEditorFoto(dataUrl, onSave);
            inputEl.value = "";
        });
    });
}

function garantirModalEditorFoto() {
    if (document.getElementById("fotoEditModal")) return;
    var modal = document.createElement("div");
    modal.id = "fotoEditModal";
    modal.className = "modal";
    modal.innerHTML =
        '<div class="modal-box foto-edit-box">' +
        '<button type="button" class="close-modal" onclick="fecharEditorFoto()">×</button>' +
        '<div class="modal-icon"><i class="fa-solid fa-crop"></i></div>' +
        '<h2>Ajustar foto de perfil</h2>' +
        '<p>Escolha o tamanho e a posição da foto.</p>' +
        '<div class="foto-edit-preview-wrap">' +
        '<div class="foto-edit-preview" id="fotoEditPreview">' +
        '<img id="fotoEditImg" src="" alt="Prévia">' +
        '</div></div>' +
        '<div class="foto-edit-controls">' +
        '<label>Tamanho <span id="fotoScaleVal">100%</span></label>' +
        '<input type="range" id="fotoScale" min="100" max="250" value="100" step="5">' +
        '<label>Posição horizontal <span id="fotoXVal">50%</span></label>' +
        '<input type="range" id="fotoPosX" min="0" max="100" value="50" step="1">' +
        '<label>Posição vertical <span id="fotoYVal">50%</span></label>' +
        '<input type="range" id="fotoPosY" min="0" max="100" value="50" step="1">' +
        '</div>' +
        '<div class="foto-edit-actions">' +
        '<button type="button" class="btn-outline" onclick="fecharEditorFoto()">Cancelar</button>' +
        '<button type="button" class="btn-primary" onclick="salvarEditorFoto()">Salvar foto</button>' +
        '</div></div>';
    document.body.appendChild(modal);

    function atualizarPreview() {
        var img = document.getElementById("fotoEditImg");
        var scale = Number(document.getElementById("fotoScale").value) / 100;
        var x = document.getElementById("fotoPosX").value;
        var y = document.getElementById("fotoPosY").value;
        document.getElementById("fotoScaleVal").textContent = Math.round(scale * 100) + "%";
        document.getElementById("fotoXVal").textContent = x + "%";
        document.getElementById("fotoYVal").textContent = y + "%";
        if (img) {
            img.style.transform = "scale(" + scale + ")";
            img.style.objectPosition = x + "% " + y + "%";
        }
    }
    ["fotoScale", "fotoPosX", "fotoPosY"].forEach(function (id) {
        document.getElementById(id).addEventListener("input", atualizarPreview);
    });
}

function abrirEditorFoto(dataUrl, onSave) {
    garantirModalEditorFoto();
    _fotoEditCallback = onSave;
    _fotoEditDataUrl = dataUrl;
    var img = document.getElementById("fotoEditImg");
    img.src = dataUrl;
    document.getElementById("fotoScale").value = 100;
    document.getElementById("fotoPosX").value = 50;
    document.getElementById("fotoPosY").value = 50;
    img.style.transform = "scale(1)";
    img.style.objectPosition = "50% 50%";
    document.getElementById("fotoScaleVal").textContent = "100%";
    document.getElementById("fotoXVal").textContent = "50%";
    document.getElementById("fotoYVal").textContent = "50%";
    document.getElementById("fotoEditModal").classList.add("active");
}

function fecharEditorFoto() {
    var m = document.getElementById("fotoEditModal");
    if (m) m.classList.remove("active");
    _fotoEditCallback = null;
    _fotoEditDataUrl = null;
}

function salvarEditorFoto() {
    if (!_fotoEditCallback || !_fotoEditDataUrl) {
        fecharEditorFoto();
        return;
    }
    var scale = Number(document.getElementById("fotoScale").value) / 100;
    var x = Number(document.getElementById("fotoPosX").value);
    var y = Number(document.getElementById("fotoPosY").value);
    var pos = { scale: scale, x: x, y: y };
    _fotoEditCallback(_fotoEditDataUrl, pos);
    fecharEditorFoto();
}

function getMateriaisProfessor(email) {
    var all = JSON.parse(localStorage.getItem("materiaisProfessor") || "{}");
    return all[email] || [];
}

function setMateriaisProfessor(email, lista) {
    var all = JSON.parse(localStorage.getItem("materiaisProfessor") || "{}");
    all[email] = lista;
    localStorage.setItem("materiaisProfessor", JSON.stringify(all));
}

/* ---------- Avaliações ---------- */

function getAvaliacoes(profEmail) {
    var all = JSON.parse(localStorage.getItem("avaliacoes") || "{}");
    return all[profEmail] || [];
}

function setAvaliacoes(profEmail, lista) {
    var all = JSON.parse(localStorage.getItem("avaliacoes") || "{}");
    all[profEmail] = lista;
    localStorage.setItem("avaliacoes", JSON.stringify(all));
}

function mediaAvaliacoes(profEmail) {
    var lista = getAvaliacoes(profEmail);
    if (!lista.length) return { media: 5.0, total: 0 };
    var soma = lista.reduce(function (s, a) { return s + Number(a.nota); }, 0);
    return { media: Math.round((soma / lista.length) * 10) / 10, total: lista.length };
}

function alunoJaAvaliou(profEmail, alunoEmail) {
    return getAvaliacoes(profEmail).some(function (a) { return a.alunoEmail === alunoEmail; });
}

function alunoTeveAulaCom(profEmail, alunoEmail) {
    var prof = getProfessores().find(function (p) { return p.email === profEmail; });
    if (!prof) return false;
    return getAgendamentos().some(function (a) {
        return isConfirmada(a) &&
            (a.email === alunoEmail) &&
            (a.professor === prof.nome || a.professorEmail === profEmail);
    });
}

/* ---------- Chat (aluno↔prof e prof↔prof) ---------- */

function chatKey(emailA, emailB) {
    var a = String(emailA).toLowerCase();
    var b = String(emailB).toLowerCase();
    // chave estável (ordem alfabética) para conversas entre professores
    if (a < b) return a + "|" + b;
    return b + "|" + a;
}

// Mantém compatibilidade com chats antigos no formato prof|aluno
function chatKeyLegacy(profEmail, alunoEmail) {
    return String(profEmail).toLowerCase() + "|" + String(alunoEmail).toLowerCase();
}

function getChat(emailA, emailB) {
    var all = JSON.parse(localStorage.getItem("chats") || "{}");
    var k = chatKey(emailA, emailB);
    if (all[k]) return all[k];
    // fallback legado
    var leg = chatKeyLegacy(emailA, emailB);
    if (all[leg]) return all[leg];
    leg = chatKeyLegacy(emailB, emailA);
    if (all[leg]) return all[leg];
    return [];
}

function setChat(emailA, emailB, msgs) {
    var all = JSON.parse(localStorage.getItem("chats") || "{}");
    all[chatKey(emailA, emailB)] = msgs;
    localStorage.setItem("chats", JSON.stringify(all));
}

function enviarMensagemChat(emailA, emailB, deTipo, texto, deEmail) {
    texto = (texto || "").trim();
    if (!texto) return;
    var msgs = getChat(emailA, emailB);
    msgs.push({
        de: deTipo, // 'aluno' | 'professor'
        deEmail: deEmail || null,
        texto: texto,
        data: new Date().toISOString()
    });
    setChat(emailA, emailB, msgs);
}

function listarConversasProfessor(profEmail) {
    var all = JSON.parse(localStorage.getItem("chats") || "{}");
    var me = String(profEmail).toLowerCase();
    var conversas = [];
    var seen = {};

    function addConv(outroEmail, msgs, nome, tipo) {
        var key = String(outroEmail).toLowerCase();
        if (seen[key] || key === me) return;
        seen[key] = true;
        conversas.push({
            outroEmail: outroEmail,
            alunoEmail: outroEmail, // compat
            msgs: msgs || [],
            ultima: (msgs && msgs.length) ? msgs[msgs.length - 1] : null,
            nomeAluno: nome,
            tipoContato: tipo || "aluno"
        });
    }

    Object.keys(all).forEach(function (k) {
        var parts = k.split("|");
        if (parts.length !== 2) return;
        if (parts[0] !== me && parts[1] !== me) return;
        var outro = parts[0] === me ? parts[1] : parts[0];
        var msgs = all[k] || [];
        if (!msgs.length) return;
        var al = getAlunos().find(function (x) { return x.email.toLowerCase() === outro; });
        var pr = getProfessores().find(function (x) { return x.email.toLowerCase() === outro; });
        if (pr) addConv(pr.email, msgs, pr.nome, "professor");
        else if (al) addConv(al.email, msgs, al.nome, "aluno");
        else addConv(outro, msgs, outro, "aluno");
    });

    // alunos com aula agendada
    var prof = getProfessores().find(function (p) { return p.email === profEmail; });
    if (prof) {
        getAgendamentos().forEach(function (a) {
            if ((a.professor === prof.nome || a.professorEmail === profEmail) &&
                statusAgendamento(a) !== "recusada" && a.email) {
                addConv(a.email, getChat(profEmail, a.email), a.nome, "aluno");
            }
        });
    }

    // outros professores (para iniciar conversa)
    getProfessores().forEach(function (p) {
        if (p.email.toLowerCase() !== me) {
            addConv(p.email, getChat(profEmail, p.email), p.nome, "professor");
        }
    });

    return conversas;
}

function getQueryParam(name) {
    var params = new URLSearchParams(window.location.search);
    return params.get(name);
}


/* ---------- Status de agendamento ---------- */

function statusAgendamento(a) {
    return a.status || "confirmada"; // dados antigos sem status = já confirmados
}

function isConfirmada(a) {
    return statusAgendamento(a) === "confirmada";
}

function isPendente(a) {
    return statusAgendamento(a) === "pendente";
}


/* ---------- Menu mobile ---------- */

function toggleMenu() {
    const menu = document.getElementById("menu");
    if (!menu) return;
    if (menu.style.display === "flex") {
        menu.style.display = "none";
    } else {
        menu.style.display = "flex";
        menu.style.flexDirection = "column";
        menu.style.position = "absolute";
        menu.style.top = "76px";
        menu.style.left = "0";
        menu.style.right = "0";
        menu.style.padding = "20px";
        menu.style.background = "white";
        menu.style.borderBottom = "1px solid #eee";
        menu.style.zIndex = "999";
    }
}

/* ---------- Modais ---------- */

function abrirLogin() {
    const el = document.getElementById("loginModal");
    if (el) el.classList.add("active");
}

/**
 * Login direto com conta Google (simulado no front-end).
 * Em produção, integraria com Google Identity Services / OAuth.
 * Aqui: pede o tipo de conta e cria/loga um usuário vinculado ao Google.
 */
function listarContasGoogleLocais() {
    var contas = [];
    getProfessores().forEach(function (p) {
        contas.push({
            id: p.id, nome: p.nome, email: p.email, tipo: "professor",
            foto: p.foto, disciplina: p.disciplina, disciplinas: p.disciplinas,
            bio: p.bio || "", loginGoogle: !!p.loginGoogle
        });
    });
    getAlunos().forEach(function (a) {
        contas.push({
            id: a.id, nome: a.nome, email: a.email, tipo: "aluno",
            foto: a.foto, bio: a.bio || "", loginGoogle: !!a.loginGoogle
        });
    });
    return contas;
}

function loginComGoogle() {
    // Abre o seletor de contas do Google em nova aba (contas já salvas no navegador)
    try {
        var continueUrl = window.location.href.split("#")[0];
        var googleUrl = "https://accounts.google.com/AccountChooser?continue=" +
            encodeURIComponent(continueUrl) + "&hl=pt-BR";
        window.open(googleUrl, "_blank", "noopener,noreferrer");
    } catch (e) { /* ignore */ }

    // Em paralelo, mostra seletor local (contas já cadastradas no app + nova conta)
    garantirModalGoogleContas();
    renderizarListaContasGoogle();
    fecharModal("loginModal");
    document.getElementById("googleContasModal").classList.add("active");
}

function garantirModalGoogleContas() {
    if (document.getElementById("googleContasModal")) return;
    var modal = document.createElement("div");
    modal.id = "googleContasModal";
    modal.className = "modal";
    modal.innerHTML =
        '<div class="modal-box google-contas-box">' +
        '<button type="button" class="close-modal" onclick="fecharModal(\'googleContasModal\')">×</button>' +
        '<div class="google-logo-row"><i class="fa-brands fa-google"></i> <span>Entrar com Google</span></div>' +
        '<h2>Escolha uma conta</h2>' +
        '<p class="google-hint">Selecione uma conta já salva no app ou use outra conta.</p>' +
        '<div id="googleContasLista" class="google-contas-lista"></div>' +
        '<button type="button" class="google-outra-conta" onclick="usarOutraContaGoogle()">' +
        '<i class="fa-solid fa-user-plus"></i> Usar outra conta</button>' +
        '</div>';
    document.body.appendChild(modal);
}

function renderizarListaContasGoogle() {
    var lista = document.getElementById("googleContasLista");
    if (!lista) return;
    var contas = listarContasGoogleLocais();
    if (!contas.length) {
        lista.innerHTML = '<p class="google-empty">Nenhuma conta salva ainda. Use outra conta.</p>';
        return;
    }
    lista.innerHTML = contas.map(function (c, i) {
        var inicial = (c.nome || "?").charAt(0).toUpperCase();
        var avatar = c.foto
            ? '<img src="' + c.foto + '" alt="">'
            : '<span class="google-avatar-letter">' + inicial + '</span>';
        var tipoLabel = c.tipo === "professor" ? "Professor" : "Aluno";
        return (
            '<button type="button" class="google-conta-item" onclick="selecionarContaGoogle(' + i + ')">' +
            '<div class="google-conta-avatar">' + avatar + '</div>' +
            '<div class="google-conta-info">' +
            '<strong>' + escapeHtml(c.nome) + '</strong>' +
            '<span>' + escapeHtml(c.email) + '</span>' +
            '<small>' + tipoLabel + '</small>' +
            '</div></button>'
        );
    }).join("");
    window._googleContasCache = contas;
}

function selecionarContaGoogle(idx) {
    var contas = window._googleContasCache || listarContasGoogleLocais();
    var c = contas[idx];
    if (!c) return;
    setUsuarioLogado({
        id: c.id,
        nome: c.nome,
        email: c.email,
        tipo: c.tipo,
        disciplina: c.disciplina || undefined,
        disciplinas: c.disciplinas || undefined,
        bio: c.bio || "",
        foto: c.foto || undefined,
        loginGoogle: true
    });
    atualizarUIUsuario();
    fecharModal("googleContasModal");
    mostrarToast("Login com Google realizado! Olá, " + c.nome);
    if (c.tipo === "professor") {
        window.location.href = "perfil-professor.html";
    } else {
        window.location.href = "perfil-aluno.html";
    }
}

function usarOutraContaGoogle() {
    // Abre Google AccountChooser de novo e pede dados para vincular no app
    try {
        var googleUrl = "https://accounts.google.com/AccountChooser?hl=pt-BR";
        window.open(googleUrl, "_blank", "noopener,noreferrer");
    } catch (e) {}

    var tipo = window.prompt(
        "Após selecionar no Google, informe o tipo de conta neste app:\\n\\nDigite 'aluno' ou 'professor'",
        "aluno"
    );
    if (!tipo) return;
    tipo = tipo.trim().toLowerCase();
    if (tipo !== "aluno" && tipo !== "professor") {
        mostrarToast("Tipo inválido. Use 'aluno' ou 'professor'.");
        return;
    }
    var nome = window.prompt("Nome da conta Google selecionada:", "");
    if (!nome || !nome.trim()) {
        mostrarToast("Nome é obrigatório.");
        return;
    }
    nome = nome.trim();
    var email = window.prompt("E-mail da conta Google:", "");
    if (!email || !email.trim() || email.indexOf("@") < 0) {
        // gera e-mail se não informado
        var emailBase = nome.toLowerCase()
            .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
            .replace(/[^a-z0-9]+/g, ".")
            .replace(/^\.+|\.+$/g, "") || "usuario";
        email = emailBase + "@gmail.com";
    } else {
        email = email.trim().toLowerCase();
    }

    var existente = getProfessores().find(function (p) { return p.email === email; }) ||
        getAlunos().find(function (a) { return a.email === email; });
    if (existente) {
        setUsuarioLogado({
            id: existente.id,
            nome: existente.nome,
            email: existente.email,
            tipo: existente.tipo,
            disciplina: existente.disciplina || undefined,
            disciplinas: existente.disciplinas || undefined,
            bio: existente.bio || "",
            foto: existente.foto || undefined,
            loginGoogle: true
        });
        atualizarUIUsuario();
        fecharModal("googleContasModal");
        mostrarToast("Login com Google realizado! Olá, " + existente.nome);
        return;
    }

    var novo = {
        id: Date.now(),
        nome: nome,
        email: email,
        senha: "google-oauth",
        tipo: tipo,
        bio: "",
        loginGoogle: true
    };
    if (tipo === "professor") {
        var disc = window.prompt("Disciplinas que você ensina (separadas por vírgula):", "Matemática");
        var discs = (disc || "Geral").split(",").map(function (d) { return d.trim(); }).filter(Boolean);
        if (!discs.length) discs = ["Geral"];
        novo.disciplinas = discs;
        novo.disciplina = discs[0];
        var listaP = getProfessores().slice();
        listaP.push(novo);
        setProfessores(listaP);
    } else {
        var listaA = getAlunos().slice();
        listaA.push(novo);
        setAlunos(listaA);
    }
    setUsuarioLogado({
        id: novo.id,
        nome: novo.nome,
        email: novo.email,
        tipo: novo.tipo,
        disciplina: novo.disciplina || undefined,
        disciplinas: novo.disciplinas || undefined,
        bio: "",
        loginGoogle: true
    });
    atualizarUIUsuario();
    fecharModal("googleContasModal");
    mostrarToast("Conta Google vinculada! Olá, " + nome);
}


function fecharModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove("active");
}

function abrirTipoCadastro() {
    const el = document.getElementById("tipoCadastroModal");
    if (el) el.classList.add("active");
}

function escolherTipoCadastro(tipo) {
    fecharModal("tipoCadastroModal");
    abrirCadastro(tipo);
}

function abrirCadastro(tipo) {
    const modal = document.getElementById("registerModal");
    if (!modal) return;

    const titulo = document.getElementById("registerTitle");
    const desc = document.getElementById("registerDesc");
    const disciplinaGroup = document.getElementById("disciplinaGroup");
    const tipoInput = document.getElementById("registerTipo");
    const customGroup = document.getElementById("disciplinaCustomGroup");

    if (tipo === "professor") {
        if (titulo) titulo.textContent = "Cadastro de Professor";
        if (desc) desc.textContent = "Crie sua conta e defina a disciplina que você ensina.";
        if (disciplinaGroup) disciplinaGroup.style.display = "flex";
        const sel = document.getElementById("registerDisciplina");
        if (sel) sel.required = true;
        if (tipoInput) tipoInput.value = "professor";
    } else {
        if (titulo) titulo.textContent = "Cadastro de Aluno";
        if (desc) desc.textContent = "Crie sua conta para começar a agendar aulas.";
        if (disciplinaGroup) disciplinaGroup.style.display = "none";
        const sel = document.getElementById("registerDisciplina");
        if (sel) sel.required = false;
        if (customGroup) customGroup.style.display = "none";
        if (tipoInput) tipoInput.value = "aluno";
    }

    modal.classList.add("active");
}

function trocarParaCadastro() {
    fecharModal("loginModal");
    abrirTipoCadastro();
}

function trocarParaLogin() {
    fecharModal("registerModal");
    abrirLogin();
}

function onDisciplinaChange() {
    const select = document.getElementById("registerDisciplina");
    const customGroup = document.getElementById("disciplinaCustomGroup");
    const customInput = document.getElementById("registerDisciplinaCustom");
    if (!select || !customGroup) return;

    if (select.value === "__outra__") {
        customGroup.style.display = "flex";
        if (customInput) customInput.required = true;
    } else {
        customGroup.style.display = "none";
        if (customInput) customInput.required = false;
    }
}

/* ---------- Navegação ---------- */

function irParaAgendamento() {
    const el = document.getElementById("agendar");
    if (el) el.scrollIntoView({ behavior: "smooth" });
}

function selecionarDisciplina(disciplina) {
    const select = document.getElementById("discipline");
    if (select) {
        // Garante que a disciplina exista no select
        var existe = false;
        for (var i = 0; i < select.options.length; i++) {
            if (select.options[i].value === disciplina) { existe = true; break; }
        }
        if (!existe && disciplina) {
            var opt = document.createElement("option");
            opt.value = disciplina;
            opt.textContent = disciplina;
            select.appendChild(opt);
        }
        select.value = disciplina;
        atualizarProfessoresPorDisciplina();
    }
    irParaAgendamento();
}

var OUTRAS_MATERIAS = [
    "História", "Geografia", "Química", "Biologia", "Filosofia",
    "Sociologia", "Educação Física", "Artes", "Redação", "Programação",
    "Espanhol", "Francês", "Música", "Economia"
];

function abrirOutrasMaterias() {
    garantirModalOutrasMaterias();
    var modal = document.getElementById("outrasMateriasModal");
    if (modal) modal.classList.add("active");
}

function garantirModalOutrasMaterias() {
    if (document.getElementById("outrasMateriasModal")) return;
    var modal = document.createElement("div");
    modal.id = "outrasMateriasModal";
    modal.className = "modal";
    var chips = OUTRAS_MATERIAS.map(function (m) {
        return '<button type="button" class="outra-materia-chip" onclick="escolherOutraMateria(\'' + m + '\')">' + m + '</button>';
    }).join("");
    modal.innerHTML =
        '<div class="modal-box">' +
        '<button type="button" class="close-modal" onclick="fecharModal(\'outrasMateriasModal\')">×</button>' +
        '<div class="modal-icon"><i class="fa-solid fa-book-open"></i></div>' +
        '<h2>Outras matérias</h2>' +
        '<p>Escolha uma matéria ou digite outra.</p>' +
        '<div class="outras-materias-grid">' + chips + '</div>' +
        '<div class="form-group-modal" style="margin-top:16px;">' +
        '<label for="outraMateriaCustom">Ou digite:</label>' +
        '<input type="text" id="outraMateriaCustom" placeholder="Ex: Robótica">' +
        '</div>' +
        '<button type="button" class="btn-primary" onclick="escolherOutraMateriaCustom()">Continuar</button>' +
        '</div>';
    document.body.appendChild(modal);
}

function escolherOutraMateria(nome) {
    fecharModal("outrasMateriasModal");
    selecionarDisciplina(nome);
}

function escolherOutraMateriaCustom() {
    var input = document.getElementById("outraMateriaCustom");
    var nome = (input && input.value || "").trim();
    if (!nome) {
        mostrarToast("Digite o nome da matéria.");
        return;
    }
    fecharModal("outrasMateriasModal");
    selecionarDisciplina(nome);
}

function selecionarProfessor(professor) {
    const select = document.getElementById("teacher");
    const discSelect = document.getElementById("discipline");
    const prof = getProfessores().find(function (p) { return p.nome === professor; });
    if (prof && discSelect) {
        discSelect.value = prof.disciplina;
        atualizarSelectProfessores();
    }
    if (select) select.value = professor;
    atualizarHorariosDisponiveis();
    irParaAgendamento();
}

/* ---------- Toast ---------- */

function mostrarToast(mensagem) {
    const toast = document.getElementById("toast");
    const message = document.getElementById("toastMessage");
    if (!toast || !message) return;
    message.textContent = mensagem;
    toast.classList.add("active");
    setTimeout(function () {
        toast.classList.remove("active");
    }, 3500);
}

/* ---------- Selects ---------- */

function atualizarSelectProfessores() {
    const select = document.getElementById("teacher");
    if (!select) return;

    const disciplina = (document.getElementById("discipline") || {}).value || "";
    const professores = getProfessores();

    select.innerHTML = '<option value="">Selecione um professor</option>';

    const filtrados = disciplina
        ? professores.filter(function (p) { return professorEnsina(p, disciplina); })
        : professores;

    filtrados.forEach(function (p) {
        const opt = document.createElement("option");
        opt.value = p.nome;
        opt.textContent = p.nome + " (" + getDisciplinasDoProfessor(p).join(", ") + ")";
        select.appendChild(opt);
    });
}

function atualizarProfessoresPorDisciplina() {
    atualizarSelectProfessores();
}

function atualizarSelectDisciplinas() {
    const select = document.getElementById("discipline");
    if (!select) return;

    const professores = getProfessores();
    const set = {};
    DISCIPLINAS_PADRAO.forEach(function (d) { set[d] = true; });
    professores.forEach(function (p) {
        getDisciplinasDoProfessor(p).forEach(function (d) { if (d) set[d] = true; });
    });

    const disciplinas = Object.keys(set).sort();
    const valorAtual = select.value;

    select.innerHTML = '<option value="">Selecione uma disciplina</option>';
    disciplinas.forEach(function (d) {
        const opt = document.createElement("option");
        opt.value = d;
        opt.textContent = d;
        select.appendChild(opt);
    });
    if (valorAtual) select.value = valorAtual;
}

/* ---------- Lista de professores (home) ---------- */

function renderizarProfessores() {
    const container = document.getElementById("teachersList");
    if (!container) return;

    const professores = getProfessores();
    const cores = ["purple-bg", "blue-bg", "green-bg", "orange-bg"];

    container.innerHTML = "";

    professores.forEach(function (p, i) {
        const cor = cores[i % cores.length];
        const card = document.createElement("div");
        card.className = "teacher-card";
        const nomeEsc = String(p.nome).replace(/'/g, "\\'");
        const av = mediaAvaliacoes(p.email);
        const estrelas = "★".repeat(Math.round(av.media)) + "☆".repeat(5 - Math.round(av.media));
        const disp = p.disponibilidade || DISP_PADRAO;
        const diasChips = (disp.dias || []).slice(0, 5).map(function (d) {
            return '<span class="chip">' + (DIAS_NOMES[d] || d) + '</span>';
        }).join("");
        var imgStyle = "";
        var fotoPos = (p.fotoPos && typeof p.fotoPos === "object") ? p.fotoPos : { scale: 1, x: 50, y: 50 };
        var fotoStyleExtra = "";
        if (p.foto) {
            fotoStyleExtra = ' style="object-position:' + (fotoPos.x || 50) + '% ' + (fotoPos.y || 50) + '%;transform:scale(' + (fotoPos.scale || 1) + ');"';
        }
        var imgContent = p.foto
            ? '<img src="' + p.foto + '" alt="' + escapeHtml(p.nome) + '"' + fotoStyleExtra + '>'
            : '<i class="fa-solid fa-user"></i>';
        // Sempre prioriza a foto completa do professor quando existir
        if (p.foto) {
            imgStyle = "";
            imgContent = '<img class="teacher-foto-completa" src="' + p.foto + '" alt="' + escapeHtml(p.nome) + '"' + fotoStyleExtra + '>';
        } else if (p.bannerImg) {
            imgStyle = ' style="background-image:url(' + p.bannerImg + ');background-size:cover;background-position:center;"';
            imgContent = '<div class="teacher-banner-overlay"></div><i class="fa-solid fa-user" style="position:relative;z-index:1;"></i>';
        } else if (p.bannerCor) {
            imgStyle = "";
        }
        var bgClass = p.foto ? "has-teacher-photo" : (p.bannerImg ? "" : (p.bannerCor ? "banner-preset-" + p.bannerCor : cor));
        var usuarioLogado = getUsuarioLogado();
        var esconderAgendar = usuarioLogado && usuarioLogado.tipo === "professor";
        var btnAgendar = esconderAgendar
            ? ""
            : '<button type="button" onclick="selecionarProfessor(\'' + nomeEsc + '\')" class="teacher-button">Agendar</button>';
        card.innerHTML =
            '<div class="teacher-image ' + bgClass + '"' + imgStyle + '>' + imgContent + '</div>' +
            '<div class="teacher-info">' +
            "<h3>" + escapeHtml(p.nome) + "</h3>" +
            "<span>" + escapeHtml(getDisciplinasDoProfessor(p).join(" · ") || "") + "</span>" +
            (diasChips ? '<div class="teacher-disponibilidade">' + diasChips + '</div>' : '') +
            '<div class="rating">' + estrelas + ' <small>' + av.media.toFixed(1) +
            (av.total ? ' (' + av.total + ')' : '') + '</small></div>' +
            '<div class="teacher-actions">' +
            '<a href="perfil-professor.html?email=' + encodeURIComponent(p.email) + '" class="teacher-button btn-ver-perfil">Ver perfil</a>' +
            btnAgendar +
            '</div>' +
            "</div>";
        container.appendChild(card);
    });
}

/* ---------- Calendário dinâmico ---------- */

var mesAtual = new Date().getMonth();
var anoAtual = new Date().getFullYear();

var NOMES_MES = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
];

function formatarDataISO(d) {
    var y = d.getFullYear();
    var m = String(d.getMonth() + 1).padStart(2, "0");
    var day = String(d.getDate()).padStart(2, "0");
    return y + "-" + m + "-" + day;
}

function renderizarCalendario() {
    var mesLabel = document.getElementById("calendarMonth");
    var daysContainer = document.getElementById("calendarDays");
    var weekContainer = document.getElementById("calendarWeek");
    if (!mesLabel || !daysContainer) return;

    mesLabel.textContent = NOMES_MES[mesAtual] + " " + anoAtual;

    if (weekContainer) {
        weekContainer.innerHTML =
            "<span>SEG</span><span>TER</span><span>QUA</span><span>QUI</span><span>SEX</span><span>SAB</span><span>DOM</span>";
    }

    var totalDias = new Date(anoAtual, mesAtual + 1, 0).getDate();
    // getDay(): 0=Dom, 1=Seg, ..., 6=Sáb → converter para índice com segunda-feira = 0
    var primeiroDiaSemana = new Date(anoAtual, mesAtual, 1).getDay();
    var offsetInicio = primeiroDiaSemana === 0 ? 6 : primeiroDiaSemana - 1;

    var agendamentos = getAgendamentos();
    var usuario = getUsuarioLogado();
    // Só marca no calendário as aulas do usuário logado (aluno: suas confirmadas; professor: confirmadas com ele)
    if (usuario) {
        if (usuario.tipo === "aluno") {
            agendamentos = agendamentos.filter(function (a) {
                return isConfirmada(a) && (a.email === usuario.email || a.nome === usuario.nome);
            });
        } else if (usuario.tipo === "professor") {
            agendamentos = agendamentos.filter(function (a) {
                return isConfirmada(a) && (a.professor === usuario.nome || a.professorEmail === usuario.email);
            });
        }
    } else {
        // Sem login: não marca aulas de ninguém (privacidade)
        agendamentos = [];
    }
    var diasComAula = {};

    agendamentos.forEach(function (a) {
        var parts = a.data.split("-").map(Number);
        var y = parts[0], m = parts[1], d = parts[2];
        if (y === anoAtual && m - 1 === mesAtual) {
            if (!diasComAula[d]) diasComAula[d] = [];
            diasComAula[d].push(a);
        }
    });

    daysContainer.innerHTML = "";
    var hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    var hojeStr = formatarDataISO(hoje);

    // Células vazias antes do dia 1 (para alinhar com o dia da semana)
    for (var i = 0; i < offsetInicio; i++) {
        var empty = document.createElement("span");
        empty.className = "empty";
        empty.innerHTML = "&nbsp;";
        daysContainer.appendChild(empty);
    }

    // Todos os dias do mês (28/29/30/31)
    for (var dia = 1; dia <= totalDias; dia++) {
        var span = document.createElement("span");
        span.textContent = dia;
        var dataObj = new Date(anoAtual, mesAtual, dia);
        var dataStr = formatarDataISO(dataObj);
        var ds = dataObj.getDay(); // 0=Dom, 6=Sáb

        if (ds === 0 || ds === 6) {
            span.classList.add("weekend");
        }

        if (diasComAula[dia]) {
            span.classList.add("has-booking");
            span.title = diasComAula[dia]
                .map(function (a) { return a.disciplina + " " + a.horario; })
                .join(", ");
        }
        if (dataStr === hojeStr) span.classList.add("active");

        span.addEventListener("click", function (dataStrCapturada) {
            return function () {
                var spans = document.querySelectorAll("#calendarDays span:not(.empty)");
                for (var j = 0; j < spans.length; j++) spans[j].classList.remove("active");
                this.classList.add("active");
                mostrarProximoAgendamento(dataStrCapturada);
            };
        }(dataStr));

        daysContainer.appendChild(span);
    }

    mostrarProximoAgendamento();
}

function mostrarProximoAgendamento(dataFiltro) {
    var appointmentEl = document.getElementById("nextAppointment");
    var headerTitle = document.getElementById("dashboardSubject");
    var headerSmall = document.getElementById("dashboardLabel");
    if (!appointmentEl) return;

    var agora = new Date();
    var usuario = getUsuarioLogado();
    var base = getAgendamentos().filter(function (a) {
        if (!isConfirmada(a)) return false;
        if (!usuario) return false;
        if (usuario.tipo === "aluno") {
            return a.email === usuario.email || a.nome === usuario.nome;
        }
        if (usuario.tipo === "professor") {
            return a.professor === usuario.nome;
        }
        return false;
    });
    var lista = base
        .map(function (a) {
            return Object.assign({}, a, {
                datetime: new Date(a.data + "T" + a.horario + ":00")
            });
        })
        .filter(function (a) { return a.datetime >= agora; })
        .sort(function (a, b) { return a.datetime - b.datetime; });

    if (dataFiltro) {
        lista = lista.filter(function (a) { return a.data === dataFiltro; });
    }

    if (lista.length === 0) {
        if (headerSmall) headerSmall.textContent = "Próxima aula";
        if (headerTitle) headerTitle.textContent = "Nenhuma";
        appointmentEl.innerHTML =
            '<div class="appointment-icon"><i class="fa-solid fa-calendar"></i></div>' +
            "<div><strong>Sem agendamentos</strong><small>Agende sua próxima aula</small></div>" +
            "<strong>--</strong>";
        return;
    }

    var prox = lista[0];
    if (headerSmall) headerSmall.textContent = "Próxima aula";
    if (headerTitle) headerTitle.textContent = prox.disciplina;

    appointmentEl.innerHTML =
        '<div class="appointment-icon"><i class="fa-solid fa-calculator"></i></div>' +
        "<div><strong>" + prox.disciplina + "</strong><small>Prof. " + prox.professor + "</small></div>" +
        "<strong>" + prox.horario + "</strong>";
}

var ANO_MIN = new Date().getFullYear() - 1;
var ANO_MAX = new Date().getFullYear() + 1;

function mudarMes(delta) {
    mesAtual += delta;
    if (mesAtual > 11) {
        mesAtual = 0;
        anoAtual++;
    } else if (mesAtual < 0) {
        mesAtual = 11;
        anoAtual--;
    }
    // Limitação de ano: só permite ano atual ± 1
    if (anoAtual > ANO_MAX) {
        anoAtual = ANO_MAX;
        mesAtual = 11;
        mostrarToast("Não é possível avançar além de " + ANO_MAX + ".");
    } else if (anoAtual < ANO_MIN) {
        anoAtual = ANO_MIN;
        mesAtual = 0;
        mostrarToast("Não é possível voltar antes de " + ANO_MIN + ".");
    }
    renderizarCalendario();
}

/* ---------- UI usuário logado ---------- */

function atualizarUIUsuario() {
    var usuario = getUsuarioLogado();
    var navButtons = document.querySelector(".nav-buttons");
    if (!navButtons) return;

    var isProfessor = usuario && usuario.tipo === "professor";
    var isAluno = usuario && usuario.tipo === "aluno";

    // Menu principal: sem "Agendar" quando logado como professor
    var menu = document.getElementById("menu");
    if (menu) {
        var page = document.body.getAttribute("data-page") || "";
        var linksBase;
        if (page === "home") {
            linksBase =
                '<a href="#inicio">Início</a>' +
                '<a href="#disciplinas">Disciplinas</a>' +
                '<a href="#professores">Professores</a>' +
                (isProfessor ? "" : '<a href="#agendar">Agendar</a>');
        } else {
            linksBase =
                '<a href="index.html">Início</a>' +
                '<a href="index.html#disciplinas">Disciplinas</a>' +
                '<a href="index.html#professores">Professores</a>' +
                (isProfessor ? "" : '<a href="index.html#agendar">Agendar</a>');
        }
        menu.innerHTML = linksBase;
    }

    // Esconde seção de agendamento e botão do hero para professor
    var secaoAgendar = document.getElementById("agendar");
    var heroAgendarBtn = document.querySelector(".hero-buttons .btn-primary");
    if (secaoAgendar) {
        secaoAgendar.style.display = isProfessor ? "none" : "";
    }
    if (heroAgendarBtn && heroAgendarBtn.textContent && heroAgendarBtn.textContent.indexOf("Agendar") !== -1) {
        heroAgendarBtn.style.display = isProfessor ? "none" : "";
    }

    if (usuario) {
        var perfilHref = isProfessor ? "perfil-professor.html" : "perfil-aluno.html";
        var tipoLabel = isProfessor ? ' <small class="role-tag">(Prof.)</small>' : "";
        var extraBtn = "";
        if (isProfessor) {
            extraBtn =
                '<a href="perfil-professor.html#aba-solicitacoes" class="btn-outline btn-sm btn-solicitacoes">' +
                '<i class="fa-solid fa-inbox"></i> Solicitações</a>';
        } else {
            extraBtn =
                '<a href="perfil-aluno.html" class="btn-outline btn-sm">' +
                '<i class="fa-solid fa-calendar-check"></i> Minhas aulas</a>';
        }
        navButtons.innerHTML =
            '<a href="' + perfilHref + '" class="user-greeting">' +
            "Olá, <strong>" + usuario.nome.split(" ")[0] + "</strong>" + tipoLabel +
            "</a>" +
            extraBtn +
            '<a href="' + perfilHref + '" class="btn-outline btn-sm">Meu perfil</a>' +
            '<button type="button" class="btn-outline" onclick="logout()">Sair</button>';

        // Prefill formulário de agendamento se for aluno
        if (isAluno) {
            var sn = document.getElementById("studentName");
            var se = document.getElementById("studentEmail");
            if (sn && !sn.value) sn.value = usuario.nome;
            if (se && !se.value) se.value = usuario.email;
        }
    } else {
        navButtons.innerHTML =
            '<button type="button" class="btn-outline" onclick="abrirLogin()">Entrar</button>' +
            '<button type="button" class="btn-primary" onclick="abrirTipoCadastro()">Criar conta</button>';
        if (secaoAgendar) secaoAgendar.style.display = "";
        if (heroAgendarBtn) heroAgendarBtn.style.display = "";
    }
}

function logout() {
    setUsuarioLogado(null);
    atualizarUIUsuario();
    mostrarToast("Você saiu da conta.");
    // Se estiver em página de perfil, redireciona
    if (window.location.pathname.indexOf("perfil-") !== -1) {
        window.location.href = "index.html";
    }
}

function exigirLogin(tiposPermitidos) {
    var usuario = getUsuarioLogado();
    if (!usuario) {
        window.location.href = "index.html";
        return null;
    }
    if (tiposPermitidos && tiposPermitidos.indexOf(usuario.tipo) === -1) {
        var dest = usuario.tipo === "professor" ? "perfil-professor.html" : "perfil-aluno.html";
        window.location.href = dest;
        return null;
    }
    return usuario;
}

/* ---------- Eventos de formulários (home) ---------- */

function initHomeForms() {
    var bookingForm = document.getElementById("bookingForm");
    if (bookingForm) {
        var teacherSel = document.getElementById("teacher");
        var dateInput = document.getElementById("date");
        if (teacherSel) teacherSel.addEventListener("change", atualizarHorariosDisponiveis);
        if (dateInput) dateInput.addEventListener("change", atualizarHorariosDisponiveis);
        var turmaSelect=document.getElementById("bookingTurma");
        if(!turmaSelect&&teacherSel){turmaSelect=document.createElement("select");turmaSelect.id="bookingTurma";turmaSelect.innerHTML='<option value="">Sem turma (opcional)</option>';teacherSel.parentNode.appendChild(turmaSelect);}
        function atualizarTurmasAgendamento(){if(!turmaSelect||!teacherSel)return;var pr=getProfessores().find(function(p){return p.nome===teacherSel.value;});turmaSelect.innerHTML='<option value="">Sem turma (opcional)</option>';if(pr)getTurmasProfessor(pr.email).forEach(function(t){var o=document.createElement("option");o.value=String(t.id);o.textContent=t.nome+" · "+t.disciplina;turmaSelect.appendChild(o);});}
        if(teacherSel)teacherSel.addEventListener("change",atualizarTurmasAgendamento);atualizarTurmasAgendamento();

        bookingForm.addEventListener("submit", function (event) {
            event.preventDefault();

            var usuario = getUsuarioLogado();
            if (!usuario) {
                mostrarToast("Faça login como aluno para solicitar uma aula.");
                abrirLogin();
                return;
            }
            if (usuario.tipo !== "aluno") {
                mostrarToast("Somente alunos podem solicitar agendamento.");
                return;
            }

            var disciplina = document.getElementById("discipline").value;
            var professor = document.getElementById("teacher").value;
            var data = document.getElementById("date").value;
            var horario = document.getElementById("time").value;
            var anoEscolaridade = document.getElementById("studentYear") ? document.getElementById("studentYear").value : "";
            var nome = (document.getElementById("studentName").value || "").trim() || usuario.nome;
            var email = (document.getElementById("studentEmail").value || "").trim() || usuario.email;

            if (!disciplina || !professor || !data || !horario || !nome || !email || !anoEscolaridade) {
                mostrarToast("Preencha todos os campos.");
                return;
            }

            var anoEscolhido = parseInt(data.split("-")[0], 10);
            if (anoEscolhido < ANO_MIN || anoEscolhido > ANO_MAX) {
                mostrarToast("Só é possível agendar entre " + ANO_MIN + " e " + ANO_MAX + ".");
                return;
            }

            // Validar disponibilidade do professor
            var disp = getDisponibilidadeProfessor(professor);
            var partes = data.split("-").map(Number);
            var diaSemana = new Date(partes[0], partes[1] - 1, partes[2]).getDay();
            var slotsDia=disp.porDia?(disp.porDia[diaSemana]||[]):((disp.dias||[]).indexOf(diaSemana)!==-1?(disp.horarios||[]):[]);
            if (slotsDia.indexOf(horario) === -1) {
                mostrarToast("Este professor não está disponível neste dia e horário.");
                return;
            }
            if ((disp.horarios || []).indexOf(horario) === -1) {
                mostrarToast("Este horário não está na disponibilidade do professor.");
                return;
            }

            var agendamentos = getAgendamentos();
            // Conflito só com confirmadas ou pendentes do mesmo professor/horário
            var conflito = agendamentos.find(function (a) {
                return a.professor === professor && a.data === data && a.horario === horario
                    && statusAgendamento(a) !== "recusada";
            });
            if (conflito) {
                mostrarToast("Horário já ocupado ou com solicitação pendente para este professor.");
                return;
            }

            var profObj = getProfessores().find(function (p) { return p.nome === professor; });
            agendamentos.push({
                id: Date.now(),
                disciplina: disciplina,
                professor: professor,
                professorEmail: profObj ? profObj.email : null,
                data: data,
                horario: horario,
                nome: nome,
                email: email,
                anoEscolaridade: anoEscolaridade,
                turmaId: turmaSelect && turmaSelect.value ? Number(turmaSelect.value) : null,
                turmaNome: turmaSelect && turmaSelect.value ? ((getTurmasProfessor(profObj ? profObj.email : "") .find(function(t){return t.id===Number(turmaSelect.value);})||{}).nome||"") : "",
                status: "pendente"
            });
            setAgendamentos(agendamentos);

            mostrarToast("Solicitação enviada! Aguarde a confirmação do professor.");
            bookingForm.reset();
            // mantém nome/email do aluno logado
            document.getElementById("studentName").value = usuario.nome;
            document.getElementById("studentEmail").value = usuario.email;
            renderizarCalendario();
            atualizarSelectProfessores();
        });
    }

    var loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", function (event) {
            event.preventDefault();
            var email = document.getElementById("loginEmail").value.trim();
            var senha = document.getElementById("loginPassword").value;

            if (!email || !senha) {
                mostrarToast("Preencha e-mail e senha.");
                return;
            }

            var professores = getProfessores();
            var alunos = getAlunos();
            var usuario = professores.find(function (p) { return p.email === email; });
            if (!usuario) {
                usuario = alunos.find(function (a) { return a.email === email; });
            }

            if (!usuario) {
                mostrarToast("Conta não encontrada. Crie uma conta primeiro.");
                return;
            }

            // Demo: não valida senha rigidamente
            setUsuarioLogado({
                id: usuario.id,
                nome: usuario.nome,
                email: usuario.email,
                tipo: usuario.tipo,
                disciplina: usuario.disciplina || undefined,
                bio: usuario.bio || ""
            });
            atualizarUIUsuario();
            mostrarToast("Login realizado! Olá, " + usuario.nome);
            fecharModal("loginModal");
            loginForm.reset();
        });
    }

    var registerForm = document.getElementById("registerForm");
    if (registerForm) {
        registerForm.addEventListener("submit", function (event) {
            event.preventDefault();

            var nome = document.getElementById("registerName").value.trim();
            var email = document.getElementById("registerEmail").value.trim();
            var senha = document.getElementById("registerPassword").value;
            var tipo = document.getElementById("registerTipo").value;
            var disciplinaSelect = document.getElementById("registerDisciplina");
            var disciplinaCustom = document.getElementById("registerDisciplinaCustom");

            if (!nome || !email || !senha) {
                mostrarToast("Preencha todos os campos obrigatórios.");
                return;
            }

            var disciplina = "";
            if (tipo === "professor") {
                disciplina = disciplinaSelect ? disciplinaSelect.value : "";
                if (disciplina === "__outra__") {
                    disciplina = disciplinaCustom ? disciplinaCustom.value.trim() : "";
                }
                if (!disciplina) {
                    mostrarToast("Selecione ou digite a disciplina.");
                    return;
                }
            }

            var professores = getProfessores();
            var alunos = getAlunos();
            var emails = professores.map(function (p) { return p.email; })
                .concat(alunos.map(function (a) { return a.email; }));

            if (emails.indexOf(email) !== -1) {
                mostrarToast("Este e-mail já está cadastrado.");
                return;
            }

            var novoId = Date.now();

            if (tipo === "professor") {
                var listaP = JSON.parse(localStorage.getItem("professores") || "[]");
                if (listaP.length === 0) {
                    listaP = getProfessores().slice();
                }
                var novoP = {
                    id: novoId,
                    nome: nome,
                    email: email,
                    disciplina: disciplina,
                    disciplinas: [disciplina],
                    tipo: "professor",
                    bio: "",
                    senha: senha,
                    bannerCor: 1,
                    disponibilidade: { dias: [1, 2, 3, 4, 5], horarios: ["08:00", "10:00", "14:00", "16:00", "18:00"] }
                };
                listaP.push(novoP);
                setProfessores(listaP);
                setUsuarioLogado({
                    id: novoId,
                    nome: nome,
                    email: email,
                    tipo: "professor",
                    disciplina: disciplina,
                    bio: "",
                    bannerCor: 1,
                    disponibilidade: novoP.disponibilidade
                });
                mostrarToast("Conta de professor criada!");
            } else {
                var listaA = getAlunos();
                var novoA = {
                    id: novoId,
                    nome: nome,
                    email: email,
                    tipo: "aluno",
                    senha: senha
                };
                listaA.push(novoA);
                setAlunos(listaA);
                setUsuarioLogado({
                    id: novoId,
                    nome: nome,
                    email: email,
                    tipo: "aluno"
                });
                mostrarToast("Conta de aluno criada!");
            }

            fecharModal("registerModal");
            registerForm.reset();
            var customG = document.getElementById("disciplinaCustomGroup");
            if (customG) customG.style.display = "none";
            atualizarUIUsuario();
            renderizarProfessores();
            atualizarSelectProfessores();
            atualizarSelectDisciplinas();
        });
    }

    var discSelect = document.getElementById("discipline");
    if (discSelect) {
        discSelect.addEventListener("change", atualizarProfessoresPorDisciplina);
    }

    var dateInput = document.getElementById("date");
    if (dateInput) {
        dateInput.min = new Date().toISOString().split("T")[0];
        // Máximo: 31 de dezembro do próximo ano
        dateInput.max = ANO_MAX + "-12-31";
    }

    document.querySelectorAll(".modal").forEach(function (modal) {
        modal.addEventListener("click", function (event) {
            if (event.target === modal) modal.classList.remove("active");
        });
    });
}

/* ---------- Página de perfil do ALUNO ---------- */

function initPerfilAluno() {
    atualizarUIUsuario();

    var logado = getUsuarioLogado();
    var emailParam = getQueryParam("email");
    var alunos = getAlunos();
    var perfilAluno = null;
    var isDono = false;

    if (emailParam) {
        perfilAluno = alunos.find(function (a) {
            return a.email.toLowerCase() === emailParam.toLowerCase();
        });
        // também pode estar só no agendamento (nome/email)
        if (!perfilAluno) {
            var ag = getAgendamentos().find(function (a) {
                return a.email && a.email.toLowerCase() === emailParam.toLowerCase();
            });
            if (ag) {
                perfilAluno = { nome: ag.nome, email: ag.email, tipo: "aluno" };
            }
        }
        if (!perfilAluno) {
            mostrarToast("Aluno não encontrado.");
            setTimeout(function () { window.location.href = "index.html"; }, 1200);
            return;
        }
        isDono = !!(logado && logado.tipo === "aluno" &&
            logado.email.toLowerCase() === perfilAluno.email.toLowerCase());
        // professor pode ver; outros alunos também se souberem o link
        if (!logado) {
            window.location.href = "index.html";
            return;
        }
    } else {
        var usuario = exigirLogin(["aluno"]);
        if (!usuario) return;
        perfilAluno = alunos.find(function (a) { return a.email === usuario.email; }) || usuario;
        isDono = true;
        if (perfilAluno.foto) usuario.foto = perfilAluno.foto;
        if (perfilAluno.nome) usuario.nome = perfilAluno.nome;
        setUsuarioLogado(usuario);
    }

    var nomeEl = document.getElementById("perfilNome");
    var emailEl = document.getElementById("perfilEmail");
    var avatarEl = document.getElementById("perfilAvatarLetter");
    var totalEl = document.getElementById("statTotal");
    var proximasEl = document.getElementById("statProximas");
    var listaEl = document.getElementById("minhasAulas");
    var btnEditar = document.querySelector(".perfil-header .btn-primary");
    var linkAgendar = document.querySelector(".link-card");

    if (nomeEl) nomeEl.textContent = perfilAluno.nome;
    if (emailEl) emailEl.textContent = perfilAluno.email;
    aplicarFotoNoAvatar(avatarEl, perfilAluno);

    if (!isDono) {
        if (btnEditar) btnEditar.style.display = "none";
        if (linkAgendar) linkAgendar.style.display = "none";
        var fotoBtn = document.querySelector(".btn-change-photo");
        if (fotoBtn) fotoBtn.style.display = "none";
        var fotoHint = document.querySelector(".perfil-foto-hint");
        if (fotoHint) fotoHint.style.display = "none";
        if (avatarEl) {
            avatarEl.style.cursor = "default";
            avatarEl.title = "";
        }
    } else {
        var fotoInput = document.getElementById("fotoInputAluno");
        setupFotoPerfil(avatarEl, fotoInput, function (dataUrl, pos) {
            var lista = getAlunos();
            var idx = lista.findIndex(function (a) { return a.email === perfilAluno.email; });
            if (idx !== -1) {
                lista[idx].foto = dataUrl;
                lista[idx].fotoPos = pos || { scale: 1, x: 50, y: 50 };
                setAlunos(lista);
            }
            perfilAluno.foto = dataUrl;
            perfilAluno.fotoPos = pos || { scale: 1, x: 50, y: 50 };
            if (logado) {
                logado.foto = dataUrl;
                logado.fotoPos = perfilAluno.fotoPos;
                setUsuarioLogado(logado);
            }
            aplicarFotoNoAvatar(avatarEl, perfilAluno);
            mostrarToast("Foto de perfil atualizada!");
        });
    }

    var todos = getAgendamentos().filter(function (a) {
        return (a.email === perfilAluno.email || a.nome === perfilAluno.nome) &&
            statusAgendamento(a) !== "recusada";
    });

    var agora = new Date();
    var futuros = todos.filter(function (a) {
        return new Date(a.data + "T" + a.horario + ":00") >= agora;
    }).sort(function (a, b) {
        return new Date(a.data + "T" + a.horario) - new Date(b.data + "T" + b.horario);
    });

    var confirmadas = todos.filter(isConfirmada);
    var confirmadasFuturas = futuros.filter(isConfirmada);

    if (totalEl) totalEl.textContent = String(confirmadas.length);
    if (proximasEl) proximasEl.textContent = String(confirmadasFuturas.length);

    if (listaEl) {
        if (futuros.length === 0) {
            listaEl.innerHTML =
                '<div class="empty-state">' +
                '<i class="fa-solid fa-calendar-xmark"></i>' +
                (isDono
                    ? '<p>Você ainda não tem aulas agendadas.</p><a href="index.html#agendar" class="btn-primary">Agendar aula</a>'
                    : "<p>Nenhuma aula agendada.</p>") +
                "</div>";
        } else {
            listaEl.innerHTML = futuros.map(function (a) {
                var st = statusAgendamento(a);
                var badge = st === "pendente"
                    ? '<span class="status-badge pendente">Aguardando professor</span>'
                    : '<span class="status-badge confirmada">Confirmada</span>';
                var profObj = getProfessores().find(function (p) { return p.nome === a.professor; });
                var linkProf = profObj
                    ? '<a href="perfil-professor.html?email=' + encodeURIComponent(profObj.email) + '">Prof. ' +
                      escapeHtml(a.professor) + "</a>"
                    : "Prof. " + escapeHtml(a.professor);
                var btn = "";
                if (isDono) {
                    btn = st === "pendente"
                        ? '<button type="button" class="btn-cancel" onclick="cancelarAula(' + a.id + ')">Cancelar pedido</button>'
                        : '<button type="button" class="btn-cancel" onclick="cancelarAula(' + a.id + ')">Cancelar</button>';
                }
                return (
                    '<div class="aula-card">' +
                    '<div class="aula-icon"><i class="fa-solid fa-book-open"></i></div>' +
                    '<div class="aula-info">' +
                    "<strong>" + escapeHtml(a.disciplina) + "</strong>" +
                    "<span>" + linkProf + "</span>" +
                    (a.turmaNome ? '<small><i class="fa-solid fa-users"></i> Turma: '+escapeHtml(a.turmaNome)+'</small>' : '') +
                    badge +
                    "</div>" +
                    '<div class="aula-meta">' +
                    '<span><i class="fa-solid fa-calendar"></i> ' + formatarDataBR(a.data) + "</span>" +
                    '<span><i class="fa-solid fa-clock"></i> ' + a.horario + "</span>" +
                    "</div>" +
                    btn +
                    "</div>"
                );
            }).join("");
        }
    }

    // Formulário editar só para dono
    var editForm = document.getElementById("editPerfilForm");
    if (editForm && isDono) {
        document.getElementById("editNome").value = perfilAluno.nome;
        document.getElementById("editEmail").value = perfilAluno.email;

        editForm.addEventListener("submit", function (e) {
            e.preventDefault();
            var novoNome = document.getElementById("editNome").value.trim();
            var novoEmail = document.getElementById("editEmail").value.trim();
            if (!novoNome || !novoEmail) {
                mostrarToast("Preencha nome e e-mail.");
                return;
            }

            var lista = getAlunos();
            var idx = lista.findIndex(function (a) { return a.email === perfilAluno.email; });
            if (idx !== -1) {
                lista[idx].nome = novoNome;
                lista[idx].email = novoEmail;
                if (perfilAluno.foto) lista[idx].foto = perfilAluno.foto;
                setAlunos(lista);
            }

            perfilAluno.nome = novoNome;
            perfilAluno.email = novoEmail;
            if (logado) {
                logado.nome = novoNome;
                logado.email = novoEmail;
                setUsuarioLogado(logado);
            }

            if (nomeEl) nomeEl.textContent = novoNome;
            if (emailEl) emailEl.textContent = novoEmail;
            aplicarFotoNoAvatar(avatarEl, perfilAluno);
            atualizarUIUsuario();
            mostrarToast("Perfil atualizado!");
            fecharModal("editPerfilModal");
        });
    }
}

function cancelarAula(id) {
    var lista = getAgendamentos().filter(function (a) { return a.id !== id; });
    setAgendamentos(lista);
    mostrarToast("Aula cancelada.");
    initPerfilAluno();
}

function responderSolicitacao(id, novoStatus) {
    var usuario = getUsuarioLogado();
    if (!usuario || usuario.tipo !== "professor") {
        mostrarToast("Apenas o professor pode responder solicitações.");
        return;
    }
    var lista = getAgendamentos();
    var idx = lista.findIndex(function (a) { return a.id === id; });
    if (idx === -1) {
        mostrarToast("Solicitação não encontrada.");
        return;
    }
    if (lista[idx].professor !== usuario.nome) {
        mostrarToast("Esta solicitação não é sua.");
        return;
    }
    lista[idx].status = novoStatus;
    setAgendamentos(lista);
    if (novoStatus === "confirmada") {
        mostrarToast("Aula confirmada! O aluno verá na área dele.");
    } else {
        mostrarToast("Solicitação recusada.");
    }
    initPerfilProfessor();
}

function formatarDataBR(iso) {
    var parts = iso.split("-");
    if (parts.length !== 3) return iso;
    return parts[2] + "/" + parts[1] + "/" + parts[0];
}

/* ---------- Página de perfil do PROFESSOR ---------- */

function initPerfilProfessor() {
    atualizarUIUsuario();

    var logado = getUsuarioLogado();
    var emailParam = getQueryParam("email");
    var profs = getProfessores();

    // Perfil a exibir: param ou o próprio professor logado
    var perfilProf = null;
    var isDono = false;

    if (emailParam) {
        perfilProf = profs.find(function (p) {
            return p.email.toLowerCase() === emailParam.toLowerCase();
        });
        if (!perfilProf) {
            mostrarToast("Professor não encontrado.");
            setTimeout(function () { window.location.href = "index.html#professores"; }, 1200);
            return;
        }
        isDono = !!(logado && logado.tipo === "professor" &&
            logado.email.toLowerCase() === perfilProf.email.toLowerCase());
    } else {
        // Sem param: exige login como professor (meu perfil)
        var usuario = exigirLogin(["professor"]);
        if (!usuario) return;
        perfilProf = profs.find(function (p) { return p.email === usuario.email; });
        if (!perfilProf) {
            perfilProf = {
                id: usuario.id,
                nome: usuario.nome,
                email: usuario.email,
                disciplina: usuario.disciplina,
                bio: usuario.bio || "",
                foto: usuario.foto || null,
                tipo: "professor"
            };
        }
        isDono = true;
        // sincroniza dados
        if (perfilProf) {
            usuario.disciplina = perfilProf.disciplina;
            usuario.bio = perfilProf.bio || "";
            usuario.nome = perfilProf.nome;
            if (perfilProf.foto) usuario.foto = perfilProf.foto;
            setUsuarioLogado(usuario);
        }
    }

    var nomeEl = document.getElementById("perfilNome");
    var emailEl = document.getElementById("perfilEmail");
    var discEl = document.getElementById("perfilDisciplina");
    var bioEl = document.getElementById("perfilBio");
    var avatarEl = document.getElementById("perfilAvatarLetter");
    var totalEl = document.getElementById("statTotal");
    var proximasEl = document.getElementById("statProximas");
    var alunosEl = document.getElementById("statAlunos");
    var listaEl = document.getElementById("minhasAulas");
    var btnEditar = document.querySelector('.perfil-header .btn-primary');
    var uploadBox = document.querySelector(".materiais-upload-box");
    var secaoAbas = document.getElementById("secao-abas-professor");
    var tabSolicitacoes = document.querySelector('.perfil-tab[data-aba="solicitacoes"]');

    if (nomeEl) nomeEl.textContent = perfilProf.nome;
    if (emailEl) emailEl.textContent = perfilProf.email;
    if (discEl) discEl.textContent = getDisciplinasDoProfessor(perfilProf).join(" · ") || "—";
    if (bioEl) bioEl.textContent = perfilProf.bio || "Nenhuma bio definida.";
    aplicarFotoNoAvatar(avatarEl, perfilProf);

    // Avaliação média no header
    var av = mediaAvaliacoes(perfilProf.email);
    var ratingHeader = document.getElementById("perfilRating");
    if (ratingHeader) {
        var est = "★".repeat(Math.round(av.media)) + "☆".repeat(5 - Math.round(av.media));
        ratingHeader.innerHTML = est + ' <small>' + av.media.toFixed(1) +
            (av.total ? ' · ' + av.total + ' avaliação' + (av.total !== 1 ? 'ões' : '') : ' · sem avaliações') +
            '</small>';
    }

    // Banner
    aplicarBannerNoPerfil(perfilProf);

    // Disponibilidade
    setupDisponibilidadeUI(perfilProf, isDono);

    // Controles só do dono
    if (!isDono) {
        if (btnEditar) btnEditar.style.display = "none";
        if (uploadBox) uploadBox.style.display = "none";
        // Visitante: esconde aba de solicitações, mostra aulas e anexos
        if (tabSolicitacoes) tabSolicitacoes.style.display = "none";
        if (secaoAbas) {
            // Abre na aba de aulas confirmadas para visitantes
            trocarAbaProfessor("aulas");
        }
        var fotoBtn = document.querySelector(".btn-change-photo");
        if (fotoBtn) fotoBtn.style.display = "none";
        var fotoHint = document.querySelector(".perfil-foto-hint");
        if (fotoHint) fotoHint.style.display = "none";
        if (avatarEl) {
            avatarEl.style.cursor = "default";
            avatarEl.title = "";
        }
        var bannerAct = document.getElementById("bannerActions");
        if (bannerAct) bannerAct.style.display = "none";
    } else {
        var bannerAct = document.getElementById("bannerActions");
        if (bannerAct) bannerAct.style.display = "flex";
        setupBannerUpload(perfilProf);
        // Troca de foto
        var fotoInput = document.getElementById("fotoInputProf");
        setupFotoPerfil(avatarEl, fotoInput, function (dataUrl, pos) {
            var lista = getProfessores();
            if (!localStorage.getItem("professores")) lista = getProfessores().slice();
            var fotoPos = pos || { scale: 1, x: 50, y: 50 };
            var idx = lista.findIndex(function (p) { return p.email === perfilProf.email; });
            if (idx !== -1) {
                lista[idx].foto = dataUrl;
                lista[idx].fotoPos = fotoPos;
                setProfessores(lista);
            } else {
                lista.push({
                    id: perfilProf.id || Date.now(),
                    nome: perfilProf.nome,
                    email: perfilProf.email,
                    disciplina: perfilProf.disciplina,
                    tipo: "professor",
                    bio: perfilProf.bio || "",
                    foto: dataUrl,
                    fotoPos: fotoPos,
                    bannerCor: perfilProf.bannerCor || 1,
                    disponibilidade: perfilProf.disponibilidade || DISP_PADRAO
                });
                setProfessores(lista);
            }
            perfilProf.foto = dataUrl;
            perfilProf.fotoPos = fotoPos;
            if (logado) {
                logado.foto = dataUrl;
                logado.fotoPos = fotoPos;
                setUsuarioLogado(logado);
            }
            aplicarFotoNoAvatar(avatarEl, perfilProf);
            if (typeof renderizarProfessores === "function") renderizarProfessores();
            mostrarToast("Foto de perfil atualizada!");
        });

        }

    // Materiais (aba Anexos): visíveis para quem está logado
    if (logado) {
        renderizarMateriais(perfilProf.email, isDono);
    }

    // Abre aba conforme hash da URL (#aba-solicitacoes, #aba-aulas, #aba-anexos)
    var hash = (window.location.hash || "").replace("#", "");
    if (hash === "aba-solicitacoes" || hash === "secao-solicitacoes") {
        if (isDono) trocarAbaProfessor("solicitacoes");
        else trocarAbaProfessor("aulas");
    } else if (hash === "aba-aulas") {
        trocarAbaProfessor("aulas");
    } else if (hash === "aba-anexos") {
        trocarAbaProfessor("anexos");
    } else if (isDono) {
        trocarAbaProfessor("solicitacoes");
    }

    var todos = getAgendamentos().filter(function (a) {
        return a.professor === perfilProf.nome || a.professorEmail === perfilProf.email;
    });

    var agora = new Date();
    var pendentes = todos.filter(function (a) {
        return isPendente(a) && new Date(a.data + "T" + a.horario + ":00") >= agora;
    }).sort(function (a, b) {
        return new Date(a.data + "T" + a.horario) - new Date(b.data + "T" + b.horario);
    });

    var confirmadas = todos.filter(isConfirmada);
    var futuros = confirmadas.filter(function (a) {
        return new Date(a.data + "T" + a.horario + ":00") >= agora;
    }).sort(function (a, b) {
        return new Date(a.data + "T" + a.horario) - new Date(b.data + "T" + b.horario);
    });

    var alunosUnicos = {};
    confirmadas.forEach(function (a) { alunosUnicos[a.email] = true; });

    if (totalEl) totalEl.textContent = String(confirmadas.length);
    if (proximasEl) proximasEl.textContent = String(futuros.length);
    if (alunosEl) alunosEl.textContent = String(Object.keys(alunosUnicos).length);

    // Solicitações e agenda só para o dono
    if (isDono) {
        var listaSol = document.getElementById("listaSolicitacoes");
        if (listaSol) {
            if (pendentes.length === 0) {
                listaSol.innerHTML =
                    '<div class="empty-state">' +
                    '<i class="fa-solid fa-inbox"></i>' +
                    "<p>Nenhuma solicitação pendente no momento.</p>" +
                    "</div>";
            } else {
                listaSol.innerHTML = pendentes.map(function (a) {
                    return (
                        '<div class="aula-card solicitacao-card">' +
                        '<div class="aula-icon pending"><i class="fa-solid fa-clock"></i></div>' +
                        "<div class=\"aula-info\">" +
                        "<strong>" + escapeHtml(a.disciplina) + "</strong>" +
                        '<span>Aluno: <a href="perfil-aluno.html?email=' + encodeURIComponent(a.email) + '">' +
                        escapeHtml(a.nome) + "</a></span>" +
                        "<small>" + escapeHtml(a.email) + "</small>" +
                        (a.anoEscolaridade ? "<small><i class=\"fa-solid fa-graduation-cap\"></i> " + escapeHtml(a.anoEscolaridade) + "</small>" : "") +
                        '<span class="status-badge pendente">Pendente</span>' +
                        "</div>" +
                        '<div class="aula-meta">' +
                        "<span><i class=\"fa-solid fa-calendar\"></i> " + formatarDataBR(a.data) + "</span>" +
                        "<span><i class=\"fa-solid fa-clock\"></i> " + a.horario + "</span>" +
                        "</div>" +
                        '<div class="solicitacao-actions">' +
                        '<button type="button" class="btn-accept" onclick="responderSolicitacao(' + a.id + ', \'confirmada\')">Aceitar</button>' +
                        '<button type="button" class="btn-reject" onclick="responderSolicitacao(' + a.id + ', \'recusada\')">Recusar</button>' +
                        "</div>" +
                        "</div>"
                    );
                }).join("");
            }
        }

        if (listaEl) {
            if (confirmadas.length === 0) {
                listaEl.innerHTML =
                    '<div class="empty-state">' +
                    '<i class="fa-solid fa-calendar-xmark"></i>' +
                    "<p>Nenhuma aula confirmada com você ainda.</p>" +
                    "</div>";
            } else {
                listaEl.innerHTML = confirmadas.slice().sort(function(a,b){return new Date(a.data+"T"+a.horario)-new Date(b.data+"T"+b.horario);}).map(function (a) {
                    return (
                        '<div class="aula-card">' +
                        '<div class="aula-icon teacher"><i class="fa-solid fa-user-graduate"></i></div>' +
                        "<div class=\"aula-info\">" +
                        "<strong>" + escapeHtml(a.disciplina) + "</strong>" +
                        '<span>Aluno: <a href="perfil-aluno.html?email=' + encodeURIComponent(a.email) + '">' +
                        escapeHtml(a.nome) + "</a></span>" +
                        "<small>" + escapeHtml(a.email) + "</small>" +
                        (a.anoEscolaridade ? "<small><i class=\"fa-solid fa-graduation-cap\"></i> " + escapeHtml(a.anoEscolaridade) + "</small>" : "") +
                        '<span class="status-badge confirmada">Confirmada</span>' +
                        "</div>" +
                        '<div class="aula-meta">' +
                        "<span><i class=\"fa-solid fa-calendar\"></i> " + formatarDataBR(a.data) + "</span>" +
                        "<span><i class=\"fa-solid fa-clock\"></i> " + a.horario + "</span>" +
                        "</div>" +
                        "</div>"
                    );
                }).join("");
            }
        }
    } else if (listaEl) {
            // Visitante: resumo público das aulas confirmadas (sem dados do aluno)
            if (futuros.length === 0) {
                listaEl.innerHTML =
                    '<div class="empty-state">' +
                    '<i class="fa-solid fa-calendar-xmark"></i>' +
                    "<p>Nenhuma aula confirmada no momento.</p>" +
                    "</div>";
            } else {
                listaEl.innerHTML = futuros.map(function (a) {
                    return (
                        '<div class="aula-card">' +
                        '<div class="aula-icon teacher"><i class="fa-solid fa-chalkboard-user"></i></div>' +
                        '<div class="aula-info">' +
                        "<strong>" + escapeHtml(a.disciplina) + "</strong>" +
                        '<span class="status-badge confirmada">Confirmada</span>' +
                        "</div>" +
                        '<div class="aula-meta">' +
                        "<span><i class=\"fa-solid fa-calendar\"></i> " + formatarDataBR(a.data) + "</span>" +
                        "<span><i class=\"fa-solid fa-clock\"></i> " + a.horario + "</span>" +
                        "</div>" +
                        "</div>"
                    );
                }).join("");
            }
    }

    if (isDono) {
        // Formulário editar
        var editForm = document.getElementById("editPerfilForm");
        if (editForm) {
            document.getElementById("editNome").value = perfilProf.nome;
            document.getElementById("editEmail").value = perfilProf.email;
            document.getElementById("editDisciplina").value = getDisciplinasDoProfessor(perfilProf).join(", ");
            document.getElementById("editBio").value = perfilProf.bio || "";

            editForm.addEventListener("submit", function (e) {
                e.preventDefault();
                var novoNome = document.getElementById("editNome").value.trim();
                var novoEmail = document.getElementById("editEmail").value.trim();
                var novaDiscRaw = document.getElementById("editDisciplina").value.trim();
                var novaBio = document.getElementById("editBio").value.trim();
                var discs = novaDiscRaw.split(",").map(function (d) { return d.trim(); }).filter(Boolean);
                if (!discs.length) discs = ["Geral"];
                var novaDisc = discs[0];

                if (!novoNome || !novoEmail || !novaDiscRaw) {
                    mostrarToast("Preencha nome, e-mail e pelo menos uma disciplina.");
                    return;
                }

                var lista = getProfessores();
                if (!localStorage.getItem("professores")) {
                    lista = getProfessores().slice();
                }
                var idx = lista.findIndex(function (p) { return p.email === perfilProf.email; });
                if (idx !== -1) {
                    lista[idx].nome = novoNome;
                    lista[idx].email = novoEmail;
                    lista[idx].disciplina = novaDisc;
                    lista[idx].disciplinas = discs;
                    lista[idx].bio = novaBio;
                    if (perfilProf.foto) lista[idx].foto = perfilProf.foto;
                } else {
                    lista.push({
                        id: perfilProf.id || Date.now(),
                        nome: novoNome,
                        email: novoEmail,
                        disciplina: novaDisc,
                        disciplinas: discs,
                        tipo: "professor",
                        bio: novaBio,
                        foto: perfilProf.foto || null
                    });
                }
                setProfessores(lista);

                if (logado) {
                    logado.nome = novoNome;
                    logado.email = novoEmail;
                    logado.disciplina = novaDisc;
                    logado.disciplinas = discs;
                    logado.bio = novaBio;
                    setUsuarioLogado(logado);
                }
                perfilProf.nome = novoNome;
                perfilProf.email = novoEmail;
                perfilProf.disciplina = novaDisc;
                perfilProf.disciplinas = discs;
                perfilProf.bio = novaBio;

                if (nomeEl) nomeEl.textContent = novoNome;
                if (emailEl) emailEl.textContent = novoEmail;
                if (discEl) discEl.textContent = discs.join(" · ");
                renderizarMateriasProfessor(perfilProf, true);
                if (bioEl) bioEl.textContent = novaBio || "Nenhuma bio definida.";
                aplicarFotoNoAvatar(avatarEl, perfilProf);
                atualizarUIUsuario();
                mostrarToast("Perfil atualizado!");
                fecharModal("editPerfilModal");
            });
        }
    }

    // Avaliações e chat
    renderizarAvaliacoes(perfilProf.email, logado);
    renderizarMateriasProfessor(perfilProf, isDono);
    renderizarChatProfessor(perfilProf, logado, isDono);
}

function trocarAbaProfessor(nome) {
    var tabs = document.querySelectorAll(".perfil-tab");
    var panels = document.querySelectorAll(".perfil-tab-panel");
    tabs.forEach(function (t) {
        t.classList.toggle("active", t.getAttribute("data-aba") === nome);
    });
    panels.forEach(function (p) {
        p.classList.toggle("active", p.id === "aba-" + nome);
    });
    // Atualiza hash sem recarregar
    try {
        history.replaceState(null, "", "#aba-" + nome);
    } catch (e) {}
}

function renderizarMateriais(email,isDono){
 var el=document.getElementById("listaMateriais");if(!el)return;var mats=getMateriaisProfessor(email);
 if(!mats.length){el.innerHTML='<div class="empty-state"><i class="fa-solid fa-folder-open"></i><p>Nenhum material publicado ainda.</p></div>';return;}
 el.innerHTML=mats.filter(function(m){return isDono||m.publico!==false;}).map(function(m){
  var url=m.url||m.dataUrl||"#",title=m.nome||m.titulo||"Material",ico=m.tipo==="link"?"fa-link":(String(m.tipo).indexOf("pdf")>=0?"fa-file-pdf":(String(m.tipo).indexOf("image")>=0?"fa-file-image":"fa-file-lines"));
  return '<article class="material-card"><div class="material-icon"><i class="fa-solid '+ico+'"></i></div><div class="material-info"><strong>'+escapeHtml(title)+'</strong><span class="material-url-preview">'+escapeHtml(m.categoria||"Material")+(m.tamanho?" · "+Math.ceil(m.tamanho/1024)+" KB":"")+'</span></div><div class="material-actions"><a class="btn-download" href="'+escapeHtml(url)+'" target="_blank" rel="noopener" download="'+escapeHtml(title)+'" title="Abrir ou baixar"><i class="fa-solid fa-download"></i></a><button type="button" class="btn-download" onclick="navigator.clipboard&&navigator.clipboard.writeText('+JSON.stringify(m.url||"") +')" title="Copiar link"><i class="fa-solid fa-copy"></i></button>'+(isDono?'<button type="button" class="btn-remove-mat" onclick="removerMaterial(\''+email.replace(/'/g,"\\'")+'\','+m.id+')"><i class="fa-solid fa-trash"></i></button>':"")+'</div></article>';
 }).join("")||'<p class="disp-empty">Nenhum material público.</p>';
}
function removerMaterial(email,id){setMateriaisProfessor(email,getMateriaisProfessor(email).filter(function(m){return m.id!==id;}));renderizarMateriais(email,true);mostrarToast("Material removido.");}

function anexarLinkMaterial() {
    var logado = getUsuarioLogado();
    if (!logado || logado.tipo !== "professor") {
        mostrarToast("Somente o professor pode anexar links.");
        return;
    }
    var tituloEl = document.getElementById("materialLinkTitulo");
    var urlEl = document.getElementById("materialLinkUrl");
    if (!tituloEl || !urlEl) return;
    var titulo = (tituloEl.value || "").trim();
    var url = (urlEl.value || "").trim();
    if (!titulo) {
        mostrarToast("Informe um título para o material.");
        return;
    }
    if (!url) {
        mostrarToast("Informe o link do material.");
        return;
    }
    // Normaliza URL se não tiver protocolo
    if (!/^https?:\/\//i.test(url)) {
        url = "https://" + url;
    }
    try {
        new URL(url);
    } catch (e) {
        mostrarToast("Link inválido. Verifique a URL.");
        return;
    }
    var mats = getMateriaisProfessor(logado.email);
    mats.push({
        id: Date.now(),
        nome: titulo,
        titulo: titulo,
        url: url,
        tipo: "link",
        dataUpload: new Date().toISOString()
    });
    setMateriaisProfessor(logado.email, mats);
    renderizarMateriais(logado.email, true);
    tituloEl.value = "";
    urlEl.value = "";
    mostrarToast("Link anexado com sucesso!");
}

function renderizarAvaliacoes(profEmail, logado) {
    var secao = document.getElementById("secao-avaliacoes");
    if (!secao) return;
    secao.style.display = "block";

    var listaEl = document.getElementById("listaAvaliacoes");
    var formWrap = document.getElementById("formAvaliacaoWrap");
    var av = mediaAvaliacoes(profEmail);
    var lista = getAvaliacoes(profEmail);

    var mediaEl = document.getElementById("avaliacaoMedia");
    if (mediaEl) {
        mediaEl.innerHTML = "<strong>" + av.media.toFixed(1) + "</strong> / 5 · " +
            av.total + " avaliação" + (av.total !== 1 ? "ões" : "");
    }

    if (listaEl) {
        if (!lista.length) {
            listaEl.innerHTML =
                '<div class="empty-state"><i class="fa-solid fa-star"></i><p>Ainda não há avaliações.</p></div>';
        } else {
            listaEl.innerHTML = lista.slice().reverse().map(function (a) {
                var est = "★".repeat(a.nota) + "☆".repeat(5 - a.nota);
                return (
                    '<div class="avaliacao-card">' +
                    '<div class="avaliacao-header">' +
                    '<span class="avaliacao-estrelas">' + est + "</span>" +
                    '<span class="avaliacao-autor">' + escapeHtml(a.alunoNome || a.alunoEmail) + "</span>" +
                    '<span class="avaliacao-data">' + (a.data ? formatarDataBR(a.data.slice(0, 10)) : "") + "</span>" +
                    "</div>" +
                    (a.comentario ? '<p class="avaliacao-comentario">' + escapeHtml(a.comentario) + "</p>" : "") +
                    "</div>"
                );
            }).join("");
        }
    }

    if (formWrap) {
        var podeAvaliar = logado && logado.tipo === "aluno" &&
            alunoTeveAulaCom(profEmail, logado.email) &&
            !alunoJaAvaliou(profEmail, logado.email);
        if (podeAvaliar) {
            formWrap.style.display = "block";
            formWrap.innerHTML =
                '<form id="formAvaliacao" class="form-avaliacao">' +
                "<label>Sua nota</label>" +
                '<div class="stars-input" id="starsInput">' +
                [1, 2, 3, 4, 5].map(function (n) {
                    return '<button type="button" class="star-btn" data-nota="' + n + '">☆</button>';
                }).join("") +
                "</div>" +
                '<input type="hidden" id="avaliacaoNota" value="0">' +
                '<label for="avaliacaoComentario">Comentário (opcional)</label>' +
                '<textarea id="avaliacaoComentario" rows="2" placeholder="Como foi a aula?"></textarea>' +
                '<button type="submit" class="btn-primary">Enviar avaliação</button>' +
                "</form>";
            var notaSel = 0;
            formWrap.querySelectorAll(".star-btn").forEach(function (btn) {
                btn.addEventListener("click", function () {
                    notaSel = Number(btn.getAttribute("data-nota"));
                    document.getElementById("avaliacaoNota").value = notaSel;
                    formWrap.querySelectorAll(".star-btn").forEach(function (b, i) {
                        b.textContent = i < notaSel ? "★" : "☆";
                        b.classList.toggle("active", i < notaSel);
                    });
                });
            });
            document.getElementById("formAvaliacao").addEventListener("submit", function (e) {
                e.preventDefault();
                var nota = Number(document.getElementById("avaliacaoNota").value);
                if (!nota || nota < 1 || nota > 5) {
                    mostrarToast("Selecione uma nota de 1 a 5.");
                    return;
                }
                var comentario = (document.getElementById("avaliacaoComentario").value || "").trim();
                var listaAv = getAvaliacoes(profEmail);
                listaAv.push({
                    alunoEmail: logado.email,
                    alunoNome: logado.nome,
                    nota: nota,
                    comentario: comentario,
                    data: new Date().toISOString()
                });
                setAvaliacoes(profEmail, listaAv);
                mostrarToast("Avaliação enviada! Obrigado.");
                renderizarAvaliacoes(profEmail, logado);
            });
        } else if (logado && logado.tipo === "aluno" && alunoJaAvaliou(profEmail, logado.email)) {
            formWrap.style.display = "block";
            formWrap.innerHTML = '<p class="avaliacao-ja-feita"><i class="fa-solid fa-check"></i> Você já avaliou este professor.</p>';
        } else if (logado && logado.tipo === "aluno") {
            formWrap.style.display = "block";
            formWrap.innerHTML = '<p class="avaliacao-hint">Agende e confirme uma aula com este professor para poder avaliá-lo.</p>';
        } else {
            formWrap.style.display = "none";
        }
    }
}

function renderizarChatProfessor(perfilProf, logado, isDono) {
    var secao = document.getElementById("secao-chat");
    if (!secao) return;

    // Sem e-mail logado: não exibe o bate-papo no perfil do professor
    if (!logado || !logado.email) {
        secao.style.display = "none";
        return;
    }

    secao.style.display = "block";

    var container = document.getElementById("chatContainer");
    if (!container) return;

    if (logado && logado.tipo === "aluno") {
        var temAula = getAgendamentos().some(function (a) {
            return a.email === logado.email &&
                (a.professor === perfilProf.nome || a.professorEmail === perfilProf.email) &&
                statusAgendamento(a) !== "recusada";
        });
        if (!temAula) {
            container.innerHTML =
                '<div class="empty-state"><i class="fa-solid fa-comments"></i>' +
                "<p>Agende uma aula com este professor para iniciar o bate-papo.</p></div>";
            return;
        }
        renderizarConversa(container, perfilProf.email, logado.email, "aluno", perfilProf.nome);
        return;
    }

    if (isDono && logado && logado.tipo === "professor") {
        var conversas = listarConversasProfessor(perfilProf.email);
        var chatParam = getQueryParam("chat");
        var filtro = getQueryParam("chatTipo") || "todos"; // todos | alunos | professores

        var html = '<div class="chat-filtros">' +
            '<button type="button" class="chat-filtro-btn' + (filtro === "todos" ? " active" : "") + '" data-f="todos">Todos</button>' +
            '<button type="button" class="chat-filtro-btn' + (filtro === "alunos" ? " active" : "") + '" data-f="alunos">Alunos</button>' +
            '<button type="button" class="chat-filtro-btn' + (filtro === "professores" ? " active" : "") + '" data-f="professores">Professores</button>' +
            '</div>';

        var filtradas = conversas.filter(function (c) {
            if (filtro === "alunos") return c.tipoContato !== "professor";
            if (filtro === "professores") return c.tipoContato === "professor";
            return true;
        });

        html += '<div class="chat-layout">';
        html += '<div class="chat-sidebar"><h4>Conversas</h4><ul class="chat-lista-alunos">';
        if (!filtradas.length) {
            html += '<li class="chat-vazio-lista">Nenhuma conversa nesta lista.</li>';
        }
        filtradas.forEach(function (c) {
            var nome = c.nomeAluno || c.outroEmail || c.alunoEmail;
            var badge = c.tipoContato === "professor"
                ? '<span class="chat-badge-prof">Prof.</span>'
                : '<span class="chat-badge-aluno">Aluno</span>';
            var active = chatParam === c.alunoEmail ? " active" : "";
            html += '<li class="chat-aluno-item' + active + '">' +
                '<a href="perfil-professor.html?email=' + encodeURIComponent(perfilProf.email) +
                "&chat=" + encodeURIComponent(c.alunoEmail) +
                "&chatTipo=" + encodeURIComponent(filtro) + '">' +
                badge + " " + escapeHtml(nome) +
                (c.ultima ? "<small>" + escapeHtml((c.ultima.texto || "").slice(0, 40)) + "</small>" : "") +
                "</a></li>";
        });
        html += '</ul></div><div class="chat-main" id="chatMain"></div></div>';
        container.innerHTML = html;

        container.querySelectorAll(".chat-filtro-btn").forEach(function (btn) {
            btn.addEventListener("click", function () {
                var f = btn.getAttribute("data-f");
                var url = "perfil-professor.html?email=" + encodeURIComponent(perfilProf.email) +
                    "&chatTipo=" + encodeURIComponent(f);
                if (chatParam) url += "&chat=" + encodeURIComponent(chatParam);
                window.location.href = url;
            });
        });

        if (chatParam) {
            var conv = conversas.find(function (c) { return c.alunoEmail === chatParam; });
            var nomeOutro = conv ? conv.nomeAluno : null;
            renderizarConversa(document.getElementById("chatMain"), perfilProf.email, chatParam, "professor", nomeOutro);
        } else {
            document.getElementById("chatMain").innerHTML =
                '<div class="empty-state"><p>Selecione um contato para conversar.</p></div>';
        }
        return;
    }

    // Professor visitante logado: pode iniciar bate-papo com o dono do perfil
    if (logado && logado.tipo === "professor" && !isDono) {
        renderizarConversa(container, perfilProf.email, logado.email, "professor", perfilProf.nome);
        return;
    }

    container.innerHTML =
        '<div class="empty-state"><i class="fa-solid fa-lock"></i>' +
        "<p>Faça login como aluno (com aula agendada) ou como professor para usar o bate-papo.</p></div>";
}

function renderizarConversa(container, emailA, emailB, meuTipo, nomeOutro) {
    if (!container) return;
    var logado = getUsuarioLogado();
    var meuEmail = logado ? logado.email : null;
    var msgs = getChat(emailA, emailB);
    var alunos = getAlunos();
    var proffs = getProfessores();
    var outroEmail = (meuEmail && String(meuEmail).toLowerCase() === String(emailA).toLowerCase())
        ? emailB : emailA;
    // se emailB é o "contato" tipico
    if (meuEmail && String(meuEmail).toLowerCase() === String(emailB).toLowerCase()) {
        outroEmail = emailA;
    }
    var al = alunos.find(function (x) { return x.email === outroEmail; });
    var pr = proffs.find(function (x) { return x.email === outroEmail; });
    var tituloNome = nomeOutro || (pr && pr.nome) || (al && al.nome) || outroEmail;
    var titulo = "Chat com " + tituloNome;

    var html = '<div class="chat-box">';
    html += '<div class="chat-titulo"><i class="fa-solid fa-comments"></i> ' + escapeHtml(titulo) + "</div>";
    html += '<div class="chat-mensagens" id="chatMensagens">';
    if (!msgs.length) {
        html += '<p class="chat-vazio">Nenhuma mensagem ainda. Diga olá!</p>';
    } else {
        msgs.forEach(function (m) {
            var isMinha = false;
            if (m.deEmail && meuEmail) {
                isMinha = String(m.deEmail).toLowerCase() === String(meuEmail).toLowerCase();
            } else {
                isMinha = m.de === meuTipo;
            }
            var cls = isMinha ? "msg-minha" : "msg-outra";
            var hora = "";
            try {
                var d = new Date(m.data);
                hora = d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
            } catch (e) {}
            html += '<div class="chat-msg ' + cls + '">' +
                "<p>" + escapeHtml(m.texto) + "</p>" +
                '<span class="chat-hora">' + hora + "</span></div>";
        });
    }
    html += "</div>";
    html += '<form class="chat-form" id="chatForm">' +
        '<input type="text" id="chatInput" placeholder="Digite sua mensagem..." autocomplete="off" required>' +
        '<button type="submit" class="btn-primary"><i class="fa-solid fa-paper-plane"></i></button>' +
        "</form></div>";
    container.innerHTML = html;

    var msgsEl = document.getElementById("chatMensagens");
    if (msgsEl) msgsEl.scrollTop = msgsEl.scrollHeight;

    document.getElementById("chatForm").addEventListener("submit", function (e) {
        e.preventDefault();
        var input = document.getElementById("chatInput");
        var texto = (input.value || "").trim();
        if (!texto) return;
        enviarMensagemChat(emailA, emailB, meuTipo, texto, meuEmail);
        input.value = "";
        renderizarConversa(container, emailA, emailB, meuTipo, nomeOutro);
    });
}

function escapeHtml(str) {
    if (!str) return "";
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

/* ---------- Banner do professor ---------- */

function aplicarBannerNoPerfil(prof) {
    var banner = document.getElementById("perfilBanner");
    if (!banner || !prof) return;
    banner.className = "perfil-banner";
    banner.style.backgroundImage = "";
    if (prof.bannerImg) {
        banner.classList.add("has-image");
        banner.style.backgroundImage = "url(" + prof.bannerImg + ")";
        var btnRem = document.getElementById("btnRemoverBanner");
        if (btnRem) btnRem.style.display = "inline-flex";
    } else {
        var cor = prof.bannerCor || 1;
        banner.classList.add("banner-preset-" + cor);
        var btnRem = document.getElementById("btnRemoverBanner");
        if (btnRem) btnRem.style.display = "none";
    }
}

function salvarCampoProfessor(email, campos) {
    var lista = getProfessores();
    if (!localStorage.getItem("professores")) lista = getProfessores().slice();
    var idx = lista.findIndex(function (p) { return p.email === email; });
    if (idx !== -1) {
        Object.keys(campos).forEach(function (k) { lista[idx][k] = campos[k]; });
    } else {
        var base = Object.assign({ id: Date.now(), email: email, tipo: "professor" }, campos);
        lista.push(base);
    }
    setProfessores(lista);
    return lista[idx !== -1 ? idx : lista.length - 1];
}

function setupBannerUpload(perfilProf) {
    var input = document.getElementById("bannerInput");
    if (!input) return;
    input.addEventListener("change", function () {
        var file = input.files && input.files[0];
        if (!file) return;
        if (!file.type || file.type.indexOf("image/") !== 0) {
            mostrarToast("Selecione uma imagem.");
            input.value = "";
            return;
        }
        lerArquivoComoDataURL(file, 900 * 1024, function (dataUrl) {
            perfilProf.bannerImg = dataUrl;
            perfilProf.bannerCor = null;
            salvarCampoProfessor(perfilProf.email, { bannerImg: dataUrl, bannerCor: null });
            aplicarBannerNoPerfil(perfilProf);
            mostrarToast("Banner atualizado!");
            input.value = "";
        });
    });
}

function abrirSeletorCoresBanner() {
    document.getElementById("bannerCoresModal").classList.add("active");
}

function aplicarCorBanner(preset) {
    var page = document.body.getAttribute("data-page");
    if (page !== "perfil-professor") return;
    var logado = getUsuarioLogado();
    if (!logado || logado.tipo !== "professor") return;
    var lista = getProfessores();
    var prof = lista.find(function (p) { return p.email === logado.email; }) || logado;
    prof.bannerCor = preset;
    prof.bannerImg = null;
    salvarCampoProfessor(prof.email, { bannerCor: preset, bannerImg: null });
    aplicarBannerNoPerfil(prof);
    fecharModal("bannerCoresModal");
    mostrarToast("Cor do banner atualizada!");
}

function removerBanner() {
    var logado = getUsuarioLogado();
    if (!logado || logado.tipo !== "professor") return;
    var lista = getProfessores();
    var prof = lista.find(function (p) { return p.email === logado.email; }) || logado;
    prof.bannerImg = null;
    if (!prof.bannerCor) prof.bannerCor = 1;
    salvarCampoProfessor(prof.email, { bannerImg: null, bannerCor: prof.bannerCor || 1 });
    aplicarBannerNoPerfil(prof);
    mostrarToast("Imagem do banner removida.");
}

/* ---------- Disponibilidade de horários ---------- */

function setupDisponibilidadeUI(perfilProf, isDono) {
    var editor=document.getElementById("dispEditor"), resumo=document.getElementById("dispResumoVisitante"), desc=document.getElementById("dispDescricao");
    if(!perfilProf)return;
    var disp=perfilProf.disponibilidade||DISP_PADRAO;
    var porDia=disp.porDia||{};
    if(!Object.keys(porDia).length){
        (disp.dias||[]).forEach(function(d){porDia[d]=(disp.horarios||[]).slice();});
    }
    if(isDono){
        if(desc)desc.textContent="Defina horários específicos para cada dia. Separe horários por vírgula (ex.: 08:00, 10:00, 14:00).";
        if(editor){editor.style.display="block";editor.innerHTML='<div class="disp-personalizados" id="dispPersonalizados"></div><button type="button" class="btn-primary btn-sm" onclick="salvarDisponibilidade()"><i class="fa-solid fa-check"></i> Salvar horários</button>';}
        var wrap=document.getElementById("dispPersonalizados");
        var nomes=["Domingo","Segunda-feira","Terça-feira","Quarta-feira","Quinta-feira","Sexta-feira","Sábado"];
        if(wrap)wrap.innerHTML=nomes.map(function(n,d){return '<label class="disp-dia-linha"><strong>'+n+'</strong><input class="disp-dia-input" data-dia="'+d+'" type="text" placeholder="Ex.: 08:00, 10:00, 14:00" value="'+(porDia[d]||[]).join(", ")+'"></label>';}).join("");
    }else{
        if(desc)desc.textContent="Dias e horários em que este professor pode dar aulas.";
        if(editor)editor.style.display="none";
        if(resumo){resumo.style.display="flex";var html="";Object.keys(porDia).sort(function(a,b){return Number(a)-Number(b);}).forEach(function(d){if(porDia[d]&&porDia[d].length)html+='<span class="chip dia">'+(DIAS_NOMES[d]||d)+': '+porDia[d].join(", ")+'</span>';});if(!html)html='<span class="disp-empty">Nenhum horário definido.</span>';resumo.innerHTML=html;}
    }
}
function salvarDisponibilidade(){
    var logado=getUsuarioLogado();if(!logado||logado.tipo!=="professor"){mostrarToast("Faça login como professor.");return;}
    var porDia={},dias=[],todos=[];
    document.querySelectorAll(".disp-dia-input").forEach(function(input){
        var d=input.getAttribute("data-dia"), hs=(input.value||"").split(",").map(function(h){return h.trim();}).filter(Boolean);
        hs=hs.filter(function(h){return /^([01]\d|2[0-3]):[0-5]\d$/.test(h);}).filter(function(h,i,a){return a.indexOf(h)===i;}).sort();
        if(hs.length){porDia[d]=hs;dias.push(Number(d));hs.forEach(function(h){if(todos.indexOf(h)===-1)todos.push(h);});}
    });
    if(!dias.length){mostrarToast("Informe ao menos um horário em algum dia.");return;}
    todos.sort();var disp={dias:dias.sort(function(a,b){return a-b;}),horarios:todos,porDia:porDia};
    salvarCampoProfessor(logado.email,{disponibilidade:disp});logado.disponibilidade=disp;setUsuarioLogado(logado);
    var prof=getProfessores().find(function(p){return p.email===logado.email;});if(prof)setupDisponibilidadeUI(prof,true);
    mostrarToast("Disponibilidade salva!");
}
function getDisponibilidadeProfessor(nomeOuEmail){
    var p=getProfessores().find(function(x){return x.nome===nomeOuEmail||x.email===nomeOuEmail;});
    return (p&&p.disponibilidade)?p.disponibilidade:DISP_PADRAO;
}
function atualizarHorariosDisponiveis(){
    var teacherSel=document.getElementById("teacher"),dateInput=document.getElementById("date"),timeSel=document.getElementById("time");
    if(!teacherSel||!timeSel)return;
    var professor=teacherSel.value,data=dateInput?dateInput.value:"",valorAtual=timeSel.value;
    var disp=professor?getDisponibilidadeProfessor(professor):DISP_PADRAO,disponiveis=disp.horarios||[];
    if(data&&professor){var partes=data.split("-").map(Number),dia=new Date(partes[0],partes[1]-1,partes[2]).getDay();disponiveis=disp.porDia?(disp.porDia[dia]||[]):((disp.dias||[]).indexOf(dia)!==-1?disponiveis:[]);}
    timeSel.innerHTML='<option value="">Horário</option>';
    if(!disponiveis.length&&professor&&data){var opt=document.createElement("option");opt.textContent="Professor indisponível neste dia";opt.disabled=true;timeSel.appendChild(opt);}
    else disponiveis.forEach(function(h){var opt=document.createElement("option");opt.value=h;opt.textContent=h;timeSel.appendChild(opt);});
    if(valorAtual&&disponiveis.indexOf(valorAtual)!==-1)timeSel.value=valorAtual;
}

/* ---------- Boot ---------- */

document.addEventListener("DOMContentLoaded", function () {
    var page = document.body.getAttribute("data-page") || "home";

    atualizarUIUsuario();

    if (page === "home") {
        initHomeForms();
        atualizarSelectDisciplinas();
        atualizarSelectProfessores();
        renderizarProfessores();
        renderizarCalendario();
    } else if (page === "perfil-aluno") {
        initPerfilAluno();
    } else if (page === "perfil-professor") {
        initPerfilProfessor();
    }
});


/* ---------- Matérias do professor (múltiplas) ---------- */

var _materiaAtivaEmail = null;
var _materiaAtivaNome = null;

function renderizarMateriasProfessor(perfilProf, isDono) {
    var tabs = document.getElementById("materiasTabs");
    var painel = document.getElementById("materiaPainel");
    var addBox = document.getElementById("materiasAddBox");
    if (!tabs || !painel) return;

    var discs = getDisciplinasDoProfessor(perfilProf);
    _materiaAtivaEmail = perfilProf.email;
    if (!_materiaAtivaNome || discs.indexOf(_materiaAtivaNome) === -1) {
        _materiaAtivaNome = discs[0] || null;
    }

    if (addBox) addBox.style.display = isDono ? "flex" : "none";

    tabs.innerHTML = discs.map(function (d) {
        var active = d === _materiaAtivaNome ? " active" : "";
        var rem = isDono && discs.length > 1
            ? '<button type="button" class="mat-tab-rem" onclick="event.stopPropagation();removerMateriaProfessor(\'' +
              d.replace(/'/g, "\\'") + '\')" title="Remover"><i class="fa-solid fa-xmark"></i></button>'
            : "";
        return (
            '<button type="button" class="mat-tab' + active + '" onclick="selecionarMateriaProfessor(\'' +
            d.replace(/'/g, "\\'") + '\')">' + escapeHtml(d) + rem + "</button>"
        );
    }).join("");

    atualizarPainelMateria(perfilProf);
}

function selecionarMateriaProfessor(nome) {
    _materiaAtivaNome = nome;
    var lista = getProfessores();
    var prof = lista.find(function (p) { return p.email === _materiaAtivaEmail; });
    if (!prof) return;
    var logado = getUsuarioLogado();
    var isDono = logado && logado.tipo === "professor" && logado.email === prof.email;
    renderizarMateriasProfessor(prof, isDono);
}

function atualizarPainelMateria(perfilProf) {
    var titulo = document.getElementById("materiaAtivaTitulo");
    var listaEl = document.getElementById("materiaAulasLista");
    var stTotal = document.getElementById("matStatTotal");
    var stProx = document.getElementById("matStatProx");
    var stAlunos = document.getElementById("matStatAlunos");
    if (!titulo) return;

    var mat = _materiaAtivaNome || "—";
    titulo.textContent = mat;

    var agora = new Date();
    var aulas = getAgendamentos().filter(function (a) {
        var ehProf = a.professor === perfilProf.nome || a.professorEmail === perfilProf.email;
        return ehProf && statusAgendamento(a) !== "recusada" &&
            String(a.disciplina || "").toLowerCase() === String(mat).toLowerCase();
    });
    var confirmadas = aulas.filter(isConfirmada);
    var futuras = confirmadas.filter(function (a) {
        return new Date(a.data + "T" + a.horario + ":00") >= agora;
    });
    var alunos = {};
    confirmadas.forEach(function (a) { if (a.email) alunos[a.email] = true; });

    if (stTotal) stTotal.textContent = String(confirmadas.length);
    if (stProx) stProx.textContent = String(futuras.length);
    if (stAlunos) stAlunos.textContent = String(Object.keys(alunos).length);

    if (!listaEl) return;
    if (!aulas.length) {
        listaEl.innerHTML =
            '<div class="empty-state"><i class="fa-solid fa-book"></i>' +
            "<p>Nenhuma aula registrada para " + escapeHtml(mat) + ".</p></div>";
        return;
    }
    listaEl.innerHTML = aulas.slice(0, 12).map(function (a) {
        var st = statusAgendamento(a);
        var badge = st === "pendente" ? "pendente" : (st === "confirmada" ? "confirmada" : st);
        return (
            '<div class="aula-card">' +
            '<div class="aula-icon"><i class="fa-solid fa-chalkboard-user"></i></div>' +
            '<div class="aula-info">' +
            "<strong>" + escapeHtml(a.disciplina) + "</strong>" +
            "<span>Aluno: " + escapeHtml(a.nome || a.email || "—") + "</span>" +
            '<span class="status-badge ' + badge + '">' + escapeHtml(st) + "</span>" +
            "</div>" +
            '<div class="aula-meta">' +
            "<span><i class=\"fa-solid fa-calendar\"></i> " + formatarDataBR(a.data) + "</span>" +
            "<span><i class=\"fa-solid fa-clock\"></i> " + a.horario + "</span>" +
            "</div></div>"
        );
    }).join("");
}

function adicionarMateriaProfessor() {
    var input = document.getElementById("novaMateriaInput");
    var nome = (input && input.value || "").trim();
    if (!nome) {
        mostrarToast("Digite o nome da matéria.");
        return;
    }
    var logado = getUsuarioLogado();
    if (!logado || logado.tipo !== "professor") return;
    var lista = getProfessores();
    var idx = lista.findIndex(function (p) { return p.email === logado.email; });
    if (idx === -1) return;
    normalizarDisciplinasProf(lista[idx]);
    var discs = lista[idx].disciplinas.slice();
    if (discs.some(function (d) { return d.toLowerCase() === nome.toLowerCase(); })) {
        mostrarToast("Essa matéria já está cadastrada.");
        return;
    }
    discs.push(nome);
    lista[idx].disciplinas = discs;
    lista[idx].disciplina = discs[0];
    setProfessores(lista);
    logado.disciplinas = discs;
    logado.disciplina = discs[0];
    setUsuarioLogado(logado);
    if (input) input.value = "";
    _materiaAtivaNome = nome;
    var discEl = document.getElementById("perfilDisciplina");
    if (discEl) discEl.textContent = discs.join(" · ");
    renderizarMateriasProfessor(lista[idx], true);
    mostrarToast("Matéria \"" + nome + "\" adicionada!");
}

function removerMateriaProfessor(nome) {
    var logado = getUsuarioLogado();
    if (!logado || logado.tipo !== "professor") return;
    var lista = getProfessores();
    var idx = lista.findIndex(function (p) { return p.email === logado.email; });
    if (idx === -1) return;
    normalizarDisciplinasProf(lista[idx]);
    var discs = lista[idx].disciplinas.filter(function (d) {
        return d.toLowerCase() !== String(nome).toLowerCase();
    });
    if (!discs.length) {
        mostrarToast("É preciso manter pelo menos uma matéria.");
        return;
    }
    lista[idx].disciplinas = discs;
    lista[idx].disciplina = discs[0];
    setProfessores(lista);
    logado.disciplinas = discs;
    logado.disciplina = discs[0];
    setUsuarioLogado(logado);
    if (_materiaAtivaNome && _materiaAtivaNome.toLowerCase() === String(nome).toLowerCase()) {
        _materiaAtivaNome = discs[0];
    }
    var discEl = document.getElementById("perfilDisciplina");
    if (discEl) discEl.textContent = discs.join(" · ");
    renderizarMateriasProfessor(lista[idx], true);
    mostrarToast("Matéria removida.");
}


/* ---------- Extensões: turmas, materiais e menu rápido ---------- */
function getTurmasProfessor(email){var all=JSON.parse(localStorage.getItem("turmasProfessor")||"{}");return all[email]||[];}
function setTurmasProfessor(email,turmas){var all=JSON.parse(localStorage.getItem("turmasProfessor")||"{}");all[email]=turmas;localStorage.setItem("turmasProfessor",JSON.stringify(all));}
function renderizarTurmas(){
 var host=document.getElementById("turmasLista"),logado=getUsuarioLogado();if(!host||!logado||logado.tipo!=="professor")return;
 var turmas=getTurmasProfessor(logado.email);
 host.innerHTML=turmas.length?turmas.map(function(t){return '<article class="turma-card"><strong>'+escapeHtml(t.nome)+'</strong><span>'+escapeHtml(t.disciplina)+'</span><small>'+(t.alunos||[]).map(function(a){return escapeHtml(a.nome||a.email);}).join(", ")+'</small><div><input id="turmaAluno_'+t.id+'" placeholder="Nome ou e-mail do aluno"><button class="btn-outline btn-sm" onclick="adicionarAlunoTurma('+t.id+')">Adicionar aluno</button></div></article>';}).join(""):'<p class="disp-empty">Nenhuma turma criada.</p>';
}
function criarTurma(){
 var logado=getUsuarioLogado(),n=document.getElementById("turmaNome"),d=document.getElementById("turmaDisciplina");if(!logado||logado.tipo!=="professor"||!n||!d)return;
 if(!n.value.trim()||!d.value.trim()){mostrarToast("Informe nome e disciplina.");return;}
 var ts=getTurmasProfessor(logado.email);ts.push({id:Date.now(),nome:n.value.trim(),disciplina:d.value.trim(),alunos:[]});setTurmasProfessor(logado.email,ts);n.value="";renderizarTurmas();mostrarToast("Turma criada!");
}
function adicionarAlunoTurma(id){
 var logado=getUsuarioLogado(),inp=document.getElementById("turmaAluno_"+id);if(!logado||!inp)return;
 var q=inp.value.trim().toLowerCase(),alunos=getAlunos(),al=alunos.find(function(a){return String(a.email).toLowerCase()===q||String(a.nome).toLowerCase()===q;});
 if(!al){mostrarToast("Aluno não encontrado. Ele precisa ter cadastro.");return;}
 var ts=getTurmasProfessor(logado.email),t=ts.find(function(x){return x.id===id;});if(!t)return;
 if(!t.alunos.some(function(a){return a.email===al.email;}))t.alunos.push({nome:al.nome,email:al.email});
 setTurmasProfessor(logado.email,ts);renderizarTurmas();mostrarToast("Aluno adicionado à turma.");
}
function iniciarMenuRapido(){
 if(document.getElementById("quickMenuBtn"))return;
 var u=getUsuarioLogado(),perfil=u?(u.tipo==="professor"?"perfil-professor.html":"perfil-aluno.html"):"";
 var wrap=document.createElement("div");wrap.className="quick-menu-wrap";wrap.innerHTML='<button id="quickMenuBtn" class="quick-menu-btn" aria-label="Abrir menu"><i class="fa-solid fa-grid-2"></i></button><aside id="quickDrawer" class="quick-drawer"><button class="quick-close" id="quickClose">×</button><h3>Atalhos</h3><a href="index.html">Início</a>'+(perfil?'<a href="'+perfil+'">Meu perfil</a>':'<a href="#" onclick="abrirLogin();return false">Entrar</a>')+'<a href="index.html#agendar">Agendar aula</a>'+(u&&u.tipo==="professor"?'<a href="perfil-professor.html#aba-solicitacoes">Solicitações</a><a href="perfil-professor.html#aba-anexos">Materiais</a>':'')+'<button id="themeToggle" class="btn-outline">Alternar tema</button>'+(u?'<button id="quickLogout" class="btn-outline">Sair da conta</button>':'')+'</aside>';
 document.body.appendChild(wrap);var drawer=document.getElementById("quickDrawer");
 document.getElementById("quickMenuBtn").onclick=function(){drawer.classList.toggle("open");};
 document.getElementById("quickClose").onclick=function(){drawer.classList.remove("open");};
 document.getElementById("themeToggle").onclick=function(){document.body.classList.toggle("tema-escuro");localStorage.setItem("temaEscuro",document.body.classList.contains("tema-escuro")?"1":"0");};
 if(localStorage.getItem("temaEscuro")==="1")document.body.classList.add("tema-escuro");
 var lo=document.getElementById("quickLogout");if(lo)lo.onclick=function(){setUsuarioLogado(null);window.location.href="index.html";};
}
document.addEventListener("DOMContentLoaded",function(){
 iniciarMenuRapido();renderizarTurmas();
 var page=document.body.getAttribute("data-page");
 if(page==="perfil-professor"){
  var host=document.querySelector("#secao-materias");
  if(host&&!document.getElementById("turmasArea")){var area=document.createElement("section");area.id="turmasArea";area.className="perfil-section";area.innerHTML='<div class="section-heading-simple"><h2><i class="fa-solid fa-users"></i> Minhas turmas</h2><p>Organize alunos por turma e disciplina.</p></div><div class="turma-form"><input id="turmaNome" placeholder="Nome da turma"><input id="turmaDisciplina" placeholder="Disciplina"><button class="btn-primary btn-sm" onclick="criarTurma()">Criar turma</button></div><div id="turmasLista"></div>';host.parentNode.insertBefore(area,host.nextSibling);renderizarTurmas();}
  var box=document.getElementById("materiaisLinkBox");
  if(box&&!document.getElementById("materialArquivo")){var upload=document.createElement("div");upload.className="materiais-link-form";upload.innerHTML='<input id="materialArquivoTitulo" placeholder="Título do arquivo"><select id="materialCategoria"><option>Exercícios</option><option>Videoaulas</option><option>Resumos</option><option>Provas</option><option>Outros</option></select><input id="materialArquivo" type="file" accept=".pdf,.png,.jpg,.jpeg,.doc,.docx,.ppt,.pptx" /><button type="button" class="btn-outline" id="btnUploadMaterial">Enviar arquivo</button>';box.appendChild(upload);
   document.getElementById("btnUploadMaterial").onclick=function(){var f=document.getElementById("materialArquivo").files[0],title=document.getElementById("materialArquivoTitulo").value.trim(),cat=document.getElementById("materialCategoria").value,u=getUsuarioLogado();if(!f||!title){mostrarToast("Informe título e arquivo.");return;}lerArquivoComoDataURL(f,2*1024*1024,function(data){var ms=getMateriaisProfessor(u.email);ms.push({id:Date.now(),nome:title,titulo:title,dataUrl:data,tipo:f.type||"arquivo",categoria:cat,tamanho:f.size,publico:true});setMateriaisProfessor(u.email,ms);renderizarMateriais(u.email,true);mostrarToast("Arquivo enviado!");});};
  }
 }
});
